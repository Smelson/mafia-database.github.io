Zanoza modeller 1.7b (Zmodeler)

Created by Zanoza (www.zmodeler2.com)
Readme by Mr Robville


To install, just open the .exe installation file and follow it's steps.
Zmodeler is used for Importing and exporting Mafia's .4ds models.

it can be used for modelling aswell but isn't very efficient.

These 2 tutorials below teached me how to model:
http://www.etspe.ca/zmt/v1/
http://www.etspe.ca/zmt/v2/

If you start up the program and it's layout is all messy, just reinstal and it's fixed.

