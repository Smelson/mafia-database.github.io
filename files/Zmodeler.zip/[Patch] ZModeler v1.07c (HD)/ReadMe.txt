ZModeler 1.07c HD patch


  Author: djbozkosz
    Size: 479.1KB
Added on: 17 Mar 2015


A patch created by Djbozkosz for Zmodeler 1.07b.
It includes various tweaks made to the program's layout to match high resolution screens better and brings an overall more organized layout to Zmodeler.


NOTE: You will need to install Zmodeler 1.07b first.