Texture Resizer


  Author: djbozkosz
    Size: 4.8MB
Added on: 17 Feb 2015
 Version: 1.01.2015.217


A simple tool for batch converting textures to a power of two format. 
You can load individual textures or entire folders and use a filter to remove any textures that already have a power of two resolution. 
Then with one click on a button this tool will convert any non binary resolutions (E.G. 420x380) to it's nearest proper resolution (E.G. 512x512). 
You can also set interpolation parameters, color indexing and output folder.