4ds unlocker for Mafia The City Of Lost Heaven.


4ds unlocker is a specialy made program to unlock 4ds files 
exported from z modeler and other modeling programs so z modeler
can import the 4ds file in z modeler. just open the program and click open and crack 4ds
file and find the 4ds file you wish to unlock.
Note: Program can not unlock human 4ds files.
Note: Program creates new 4ds file with a name such as Thunderbird00_Unlocked.4ds

Enjoy!