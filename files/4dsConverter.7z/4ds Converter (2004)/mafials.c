//   Extract Mafia's 4DS-Files
//   Joerg Schmittler [jofis@saarcor.de]
#define VNR  0.38
#define DATE 71202
//
//   the very first version which has at least some use for normal people
//   so be warned that this program won't convert most of the files and even
//   if it does, the output might be unusable! but on the other hand this
//   thing should be stable enough to have some fun ;)
//
//
//   THIS PROGRAM IS FREEWARE!
//   SO THERE IS NO WARRANTY WHATSOEVER - USE AT YOUR OWN RISK!
//
//   THIS PROGRAM IS NOT DESIGNED TO DISASSEMBLE OR REVERSE ENGINEER
//   THE CODE OF MAFIA! ITS ONLY PURPOSE IS TO FIGURE OUT THE FILE
//   FORMAT OF THE MODELS IN MAFIA.
//
//   PLEASE RESPECT THE COPYRIGHT OF ILLUSION SOFTWORKS!
//
//   THE AUTHOR OF THIS PROGRAM IS NOT IN ANY WAY RELATED TO ILLUSION SOFTWORKS!
//
//
//   The parser outputs some debug infos and (if it can decode the file)
//   the model as a VRML2-file, a Wavefront OBJ file or alternatively as
//   an mgf-file (for details on MGF see this website:
//   http://radsite.lbl.gov/mgf/mgfhtml/entcont.html ).
//   Besides these real 3d formats, also a HACKER's output can be selected.
//   This output contains everything one needs to edit the files with a 
//   hex editor - this is of course only intended for real hardcore hackers!
//   
//   To use the output of this program, you have to redirect the output
//   into a file, e.g.  [linux]   mafials scene.4ds > cool.wrl
//                      [dos]     mafials.exe scene.4ds > cool.wrl
//
//   Compilation issues: the program was developed on linux and also tested
//   on dos with djgpp (use the DOS_MODE define). But since it's a very
//   simple c-program, you should get it running on roughly every system.
//
//
//   known problems: - a lot of types are not yet decoded and I guess the
//                     whole idea of case-switching is done the wrong way
//                   - groups of objects are not transformed correctly
//
//   known to work with these files: (list is too long, listing only nice models)
//   (known to work means: parsing works, conversion is mostly correct ;)
//      models/censored.4ds                 CENSORED-Sign (2 tris)
//      models/FMVvolant.4ds                Steeringwheel (400 tris)
//      models/FMVColt1911.4ds              Colt 1911 ( 658 triangles )
//      models/FMVBlackT.4ds
//      models/FMVcad_road00.4ds
//      models/cad_phaeton00.4ds
//      models/fordtTud*.4ds
//      models/budova*.4ds
//      models/fordv8tud.4ds
//      models/ambulance10.4ds
//      models/phantomtaxi00.4ds
//      models/FMVblackha00.4ds             nice looking car
//      models/toyota00.4ds                 toyota (extra car)
//      models/truckmorph00.4ds             big lorry (2869 tris)
//      models/k_hotkos.4ds                 roof-tops in hotel mission (6179 tris)
//      models/nor_salina_l.4ds             electricity for the trains (7432 tris)
//      models/vlevo.4ds                    world outside of the city (27066 tris)
//      missions/00menu/scene.4ds           intro screen
//      missions/freeride/scene.4ds         freeride city
//      missions/freeitaly/scene.4ds
//      missions/mise12-garage/scene.4ds
//      missions/mise07b-saliery/scene.4ds  Saliery->Ralf's Area
//      missions/mise20-galery/scene.4ds    Gallery, where the shootout at the end takes place!
//      missions/freekrajina/scene.4ds      world outside of the city (day?)
//      missions/Intermezzo4/scene.4ds      inside the cafe talking to the cop
//      missions/tutorial/scene.4ds         tutorial scene
//      (and many many more)


// if you are compiling this under DOS, you have to set this define!
// #define DOS_MODE


// ----- SELECT FILE FORMAT TO EXPORT TO: (select exaclty one!)
// 
// OBJ: Wavefront OBJ File Format (textures fixed)
#define OBJ
// 
// Hardcore Hack Mode
// #define HACK
//
// MGF: standard MGF Format (no textures at all)
// #define MGF
//
// MGFX: extended MGF Format (for hw ray tracer)
// #define MGFX
//
// MGFRT: extended MGF Format (for sw ray tracer)
// #define MGFRT
//
// VRML2: standard VRML2
// #define VRML2
//
// VRML2RT: VRML2 for our ray tracer
// #define VRML2RT
//
//
//
#ifdef MGFX
#ifndef MGF
#define MGF
#endif
#endif
//
#ifdef MGFRT
#ifndef MGF
#define MGF
#endif
#endif
//
#ifdef VRML2RT
#ifndef VRML
#define VRML
#endif
#endif
//
//
//
// do you want to transform and scale before exporting the vertex coordinates?
#define TRANSFORM_AND_SCALE
//
//
// do you want crippeld output for debugging purpose?
// #define CRIPPLEOUT
// 
//
// do you want to have a lot of debug info?
// #define TELL_ME_ALL



// includes 
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
// #include <math.h>


// typedefs
typedef unsigned char byte;
#ifdef DOS_MODE
typedef unsigned int uint;
#endif


// global data
//File-IO
int handle;
byte* buf;
struct stat staat;
char *scene4ds;
int globvert, obj, maxobj, robj, lod;
char savbuf[256];

#define MAXMATS 1000
char mats[MAXMATS][40]; 
char splmats[MAXMATS][40];
char this_mat[40];
char this_mat_done[MAXMATS];
float cmats[MAXMATS][10]; 

#define MAXVERTS 65536
float vertices[MAXVERTS][8];

#define MAXBLOX 4096
float trafo[MAXBLOX][10]; // this should really be a dynamic array depending on the "totalblocks" number!!
int trafref[MAXBLOX];
int traftype[MAXBLOX];

float tx, ty, tz, sx, sy, sz, rx, ry, rz, rw; // current transformation, scale- and rotation factors
float mtx, mty, mtz, msx, msy, msz, mrx, mry, mrz, mrw; // master transformation, scale- and rotation factors
int init_trans; 
int twist, mirror, twist2, mirror2;
int do_a_kill; // suppress level of detail blocks other than the highest level

#ifdef HACK
void Hprint(int start, int len) // Used for HACK-Mode
{
  int i;
  for (i=start; i<start+len*4; i+=4) printf("#       %08x --> %02x %02x %02x %02x = %f\n", i, buf[i], buf[i+1], buf[i+2], buf[i+3], *(float*)&buf[i]);
}
#endif

void showval(byte x)
{
  printf("%02x ", x);
  if ((x>31)||(x<127)) printf("%c  ", x); else printf("   ");
}

void showchar(byte x)
{
  if ((x>31)&&(x<127)) printf("%c", x); else printf(".");
}

void printrhex(int start, int end)
{
   int j,k;
   for (j=start; j<end; j++) printf("%02x ", buf[j]); printf("   ");
   k = (end-start);
   if ( k < 16 ) for (j=0; j<k; j++) printf(" ");
   for (j=start; j<end; j++) showchar(buf[j]); printf("\n");
}

int printhex(int start, int end)
{
   int j,k;
   printf("# ");
   for (j=start; j<end; j++) printf("%02x ", buf[j]); printf("   ");
   k = (end-start);
   if ( k < 16 ) for (j=0; j<k; j++) printf(" ");
   for (j=start; j<end; j++) showchar(buf[j]); printf("\n");
   return(end);
}

void printrfloats(int anz, int start)
{
  int i;
  for (i=0; i<anz; i++)
  {
    printf("%f ", *(float*)&buf[start+i*4] );
  }
  printf("\n");
}

int printfloats(int anz, int start)
{
  int i;
  for (i=0; i<anz; i++)
  {
    printf("# [%2d] %02x %02x %02x %02x --> %f\n", i, buf[start+i*4+0], buf[start+i*4+1], buf[start+i*4+2], buf[start+i*4+3], *(float*)&buf[start+i*4] );
  }
  return(start+anz*4);
}

int print2names(int start) // 2 names: liefert die anzahl gedruckter buchstaben+2 zurueck (2 bytes=>laengenkennung von namen)
{
  int i,l,p, ret,x, j;
  p=start;
  l=buf[p]; // laenge 1. name
  ret=l;
  p++;
  // braucht man fuer alle exporter, also mache ich's auch immer...
  // debug: printf("\n\nJOFIS  "); for (i=0; i<l; i++) printf(" %c %02x   ", buf[p+i], buf[p+i]); printf(" [*]\n\n");
  if ( l > 0 ) { j=0; for (i=0; i<l; i++) { if ( buf[p+i]>32 ) { this_mat[j] = buf[p+i]; j++; } } this_mat[j]=0; } 
          else { this_mat[0]='R'; this_mat[1]='O'; this_mat[2]='B'; this_mat[3]='J'; this_mat[4]=0; }
  // 
  printf("# Name1 [%02x]:  ", l);
  for (i=0; i<l; i++) if ( buf[p+i]>31) printf("%c", buf[p+i]); else printf(" "); printf("\n");
  p+=l;
  l=buf[p]; // laenge 2. name
  ret=ret+l;
  p++;
  printf("# Name2 [%02x]:  ", l);
  for (i=0; i<l; i++) if ( buf[p+i]>31) printf("%c", buf[p+i]); else printf(" "); printf("\n");
  return(ret+2);
}

void printlowercase(char x)
{
  if ( ( x >= 65 ) && ( x <= 90 ) ) x = x + 32; // Zeichen ist aus [A,..,Z] --> A=65, a=97 --> gross nach klein: +32
  printf("%c",x);  
}

int KILL;
#ifndef VRML2
int VERTEX_AREA(int start)
{
   int j, k, l, merke, subtype, i, nf, loop, this_mat_id, m, mejo;
   float x,y,z; int vA, vB, vC;
   // float mat[4][4]; float tvx, tvy, tvz, twx, twy, twz, txx, txy, txz, tyy, tyz, tzz; // fuer die quaternionen-rechnung
   // float nat[16]; float xx,xy,xz,xw, yy,yz,yw, zz,zw; // Quaternionen-Mathe V2
   // float nx, ny, nz; 
   double mat[4][4]; double tvx, tvy, tvz, twx, twy, twz, txx, txy, txz, tyy, tyz, tzz; // fuer die quaternionen-rechnung
   double nat[16]; double xx,xy,xz,xw, yy,yz,yw, zz,zw; // Quaternionen-Mathe V2
   double nx, ny, nz, jnx, jny, jnz, ju, jv, sax, say, saz; 
   double r0,r1,r2,r3;
   float ftx, fty, ftz, fsx, fsy, fsz, fftx, ffty, fftz; // temporaer modifizierte translation und skalierung

   int LODcount, aLOD;

   i=start;
   LODcount=buf[i]; i++; // number of level of detail blocks in this object
   printf("# LODcount = %d\n", LODcount);
   aLOD = 0;
   while ( aLOD < LODcount )
   {
     printf("# this is current LOD: %d @ %08x\n", aLOD, i); lod = aLOD; if ( ( do_a_kill == 1 ) && ( aLOD != 0 ) ) KILL=1; else KILL=0;
     printf("\n# Vertex-Area %d @ %08x\n\n", obj, i); 

   #ifdef MGF
    printf("# Object: %s-lod%d\n", this_mat, lod); robj++; // Objekt-Kennung
   #endif
   #ifdef OBJ
    // printf("g %s-%d-lod%d\n", this_mat, robj, lod); robj++; // Objekt-Kennung
    // do you want obj-files with smooth surfaces?
    #if 0
    printf("g %s-lod%d\ns 1\n", this_mat, lod); robj++; // Objekt-Kennung
    #else
    printf("g %s-lod%d\ns off\n", this_mat, lod); robj++; // Objekt-Kennung
    #endif
    // printf("usemtl DefaultShader\n");   // habe noch keine Ahnung wie die Shader aussehnen, also nehme ich den default!
   #endif

   printf("# unknown float = %f [ %08x ]\n", *(float*)&buf[i], *(unsigned int*)&buf[i]); i+=4;

   l=(int)buf[i]+256*(int)buf[i+1]; i+=2; // number of vertices in block
   printf("# Number of vertices in block: %d [%04x]\n", l, l); 
   if ( MAXVERTS < l ) { printf("*** ERROR *** MAXVERTS lower than number of triangles in current block!\nplease increase the #define and recompile!\n"); exit(0);}
   for (k=0; k<l; k++)
   {
     // Eckpunkte
     x=*(float*)&buf[i+ 0];
     y=*(float*)&buf[i+ 4];
     z=*(float*)&buf[i+ 8];

     // Normale
     jnx = *(float*)&buf[i+12];
     jny = *(float*)&buf[i+16];
     jnz = *(float*)&buf[i+20];
     
     // Textur-Koordinaten
     ju = *(float*)&buf[i+24];
     jv = *(float*)&buf[i+28];

     #ifdef HACK 
     printf("\n", k);
     printf("# Vertice %d\n", k);
     printf("# POSITION X,Y,Z \n"); Hprint(i, 3);
     printf("# NORMALS NX,NY,NZ \n"); Hprint(i+3*4, 3);
     printf("# TEXCOORD U,V\n"); Hprint(i+6*4, 2);
     #endif
     
     #ifdef TRANSFORM_AND_SCALE
     // TIP: Mafia Quaternionen sind Union-Quaternionen!   rx^2 + ry^2 + rz^2 + rw^2 = 1.0

     // This stuff is highly unoptimized. But who cares, as long as it's still fast enough and works!
      xx      = rx * rx;
      xy      = rx * ry;
      xz      = rx * rz;
      xw      = rx * rw;

      yy      = ry * ry;
      yz      = ry * rz;
      yw      = ry * rw;

      zz      = rz * rz;
      zw      = rz * rw;

      nat[0]  = 1 - 2 * ( yy + zz );
      nat[1]  =     2 * ( xy - zw );
      nat[2]  =     2 * ( xz + yw );

      nat[4]  =     2 * ( xy + zw );
      nat[5]  = 1 - 2 * ( xx + zz );
      nat[6]  =     2 * ( yz - xw );

      nat[8]  =     2 * ( xz - yw );
      nat[9]  =     2 * ( yz + xw );
      nat[10] = 1 - 2 * ( xx + yy );

      nat[3]  = 0;
      nat[7]  = 0;
      nat[11] = 0;
      nat[12] = 0;
      nat[13] = 0;
      nat[14] = 0;
      nat[15] = 1;

      // this document
      mat[0][0] = nat[0];
      mat[0][1] = nat[1];
      mat[0][2] = nat[2];

      mat[1][0] = nat[4];
      mat[1][1] = nat[5];
      mat[1][2] = nat[6];

      mat[2][0] = nat[8];
      mat[2][1] = nat[9];
      mat[2][2] = nat[10];

     // spiegeln:
     // if ( mirror == 0 )  -- identitaet --
     if ( mirror == 1 ) { x = -x;                   }
     if ( mirror == 2 ) {          y = -y;          }
     if ( mirror == 3 ) {                   z = -z; }
     if ( mirror == 4 ) { x = -x;  y = -y;          }
     if ( mirror == 5 ) {          y = -y;  z = -z; }
     if ( mirror == 6 ) { x = -x;           z = -z; }
     if ( mirror == 7 ) { x = -x;  y = -y;  z = -z; }

     // vertauschen
     if ( twist == 0 ) { nx = x; ny = y; nz = z; }
     if ( twist == 1 ) { nx = x; ny = z; nz = y; }
     if ( twist == 2 ) { nx = y; ny = x; nz = z; }
     if ( twist == 3 ) { nx = y; ny = z; nz = x; }
     if ( twist == 4 ) { nx = z; ny = x; nz = y; }
     if ( twist == 5 ) { nx = z; ny = y; nz = x; }
     x = nx; y = ny; z = nz;

     //
     nx = mat[0][0]*x+mat[0][1]*y+mat[0][2]*z;
     ny = mat[1][0]*x+mat[1][1]*y+mat[1][2]*z;
     nz = mat[2][0]*x+mat[2][1]*y+mat[2][2]*z;

     x = nx; y = ny; z = nz;

     // spiegeln:
     // if ( mirror2 == 0 )  -- identitaet --
     if ( mirror2 == 1 ) { x = -x;                   }
     if ( mirror2 == 2 ) {          y = -y;          }
     if ( mirror2 == 3 ) {                   z = -z; }
     if ( mirror2 == 4 ) { x = -x;  y = -y;          }
     if ( mirror2 == 5 ) {          y = -y;  z = -z; }
     if ( mirror2 == 6 ) { x = -x;           z = -z; }
     if ( mirror2 == 7 ) { x = -x;  y = -y;  z = -z; }

     // vertauschen
     if ( twist2 == 0 ) { nx = x; ny = y; nz = z; }
     if ( twist2 == 1 ) { nx = x; ny = z; nz = y; }
     if ( twist2 == 2 ) { nx = y; ny = x; nz = z; }
     if ( twist2 == 3 ) { nx = y; ny = z; nz = x; }
     if ( twist2 == 4 ) { nx = z; ny = x; nz = y; }
     if ( twist2 == 5 ) { nx = z; ny = y; nz = x; }


     x = nx * sx + tx; y = ny * sy + ty; z = nz * sz + tz; // translate and scale after rotation * THE BEST *

     sax=x; say=y; saz=z; // x,y,z speichern

     // normale auch rotieren
     x=jnx; y=jny; z=jnz;
     
     // spiegeln:
     // if ( mirror == 0 )  -- identitaet --
     if ( mirror == 1 ) { x = -x;                   }
     if ( mirror == 2 ) {          y = -y;          }
     if ( mirror == 3 ) {                   z = -z; }
     if ( mirror == 4 ) { x = -x;  y = -y;          }
     if ( mirror == 5 ) {          y = -y;  z = -z; }
     if ( mirror == 6 ) { x = -x;           z = -z; }
     if ( mirror == 7 ) { x = -x;  y = -y;  z = -z; }

     // vertauschen
     if ( twist == 0 ) { nx = x; ny = y; nz = z; }
     if ( twist == 1 ) { nx = x; ny = z; nz = y; }
     if ( twist == 2 ) { nx = y; ny = x; nz = z; }
     if ( twist == 3 ) { nx = y; ny = z; nz = x; }
     if ( twist == 4 ) { nx = z; ny = x; nz = y; }
     if ( twist == 5 ) { nx = z; ny = y; nz = x; }
     x = nx; y = ny; z = nz;
     
     //
     nx = mat[0][0]*x+mat[0][1]*y+mat[0][2]*z;
     ny = mat[1][0]*x+mat[1][1]*y+mat[1][2]*z;
     nz = mat[2][0]*x+mat[2][1]*y+mat[2][2]*z;
     
     x = nx; y = ny; z = nz;

     // spiegeln:
     // if ( mirror2 == 0 )  -- identitaet --
     if ( mirror2 == 1 ) { x = -x;                   }
     if ( mirror2 == 2 ) {          y = -y;          }
     if ( mirror2 == 3 ) {                   z = -z; }
     if ( mirror2 == 4 ) { x = -x;  y = -y;          }
     if ( mirror2 == 5 ) {          y = -y;  z = -z; }
     if ( mirror2 == 6 ) { x = -x;           z = -z; }
     if ( mirror2 == 7 ) { x = -x;  y = -y;  z = -z; }

     // vertauschen
     if ( twist2 == 0 ) { nx = x; ny = y; nz = z; }
     if ( twist2 == 1 ) { nx = x; ny = z; nz = y; }
     if ( twist2 == 2 ) { nx = y; ny = x; nz = z; }
     if ( twist2 == 3 ) { nx = y; ny = z; nz = x; }
     if ( twist2 == 4 ) { nx = z; ny = x; nz = y; }
     if ( twist2 == 5 ) { nx = z; ny = y; nz = x; }
     
     jnx=nx; jny=ny; jnz=nz;

     x=sax; y=say; z=saz;

     #endif

     vertices[k][0] = -x;   vertices[k][1] =  y;   vertices[k][2] =  z;   // Coordinates
     vertices[k][3] = -jnx; vertices[k][4] =  jny; vertices[k][5] =  jnz; // Normal
     vertices[k][6] =  ju;  vertices[k][7] =  jv;                         // Texture Coordinates

     #ifdef OBJ
     printf("v   %f %f %f\n", vertices[k][0], vertices[k][1], vertices[k][2]);
     printf("vn  %f %f %f\n", vertices[k][3], vertices[k][4], vertices[k][5]);
     printf("vt  %f %f\n",    vertices[k][6], -vertices[k][7]);
     #endif

     i+=0x20; // every vertice-set consists of 8 floats: x, y, z, nx, ny, nz, u, v
   }
   merke=l; // store number of vertices 

   nf=0; subtype = buf[i]; printf("\n# triangle-blocks: %02x @ %08x\n", subtype,i); i++; 

   while (nf<subtype)
   {
    l=(int)buf[i]+256*(int)buf[i+1]; i+=2; // number of triangles in block
    printf("# Number of triangles in block %d = %d [ %04x @ %08x ]\n", nf, l, l, i);
    j=i+l*6;
    this_mat_id = *(short int*)&buf[j];
    printf("# pre-read: tri-material: %04x/%04x (%d)  [ %02x %02x @ %08x ]\n\n", this_mat_id, maxobj, this_mat_id,  buf[j], buf[j+1], j);
    #ifdef OBJ
    /*
    if ( ( buf[j]==0 ) || (  mats[buf[j]-1][0]==0 ) ) printf("usemap off\n");
    else printf("usemap %s\n", mats[buf[j]-1]); // wir nehmen immer nur den 1. bzw. den 2. filenamen als material!!
    */
    // printf("usemtl %d-%s\n", buf[j]-1, splmats[buf[j]-1]); // wir nehmen immer nur den 1. bzw. den 2. filenamen als material!!
    printf("usemtl mafmat%02d\n", this_mat_id-1); // wir nehmen immer nur den 1. bzw. den 2. filenamen als material!!
    #endif
    #ifdef MGF
    if ( ( this_mat_id==0 ) || (  mats[this_mat_id-1][0]==0 ) ) printf("# no texture\n");
    else 
    { 
      printf("m\n    c\n    rd 0.8\n");
      //
      // Das funktioniert alles nicht:
      // printf("    cxy 0.4760 0.4015\n");
      // printf("    cxy %f %f\n",  0.265*cmats[buf[j]-1][0]*0.640 + 0.670*cmats[buf[j]-1][1]*0.290 + 0.065*cmats[buf[j]-1][2]*0.150,
      //                            0.265*cmats[buf[j]-1][0]*0.330 + 0.670*cmats[buf[j]-1][1]*0.600 + 0.065*cmats[buf[j]-1][2]*0.060 );
      // printf("    cmix %f R %f G %f B\n", 0.265*0.1, 0.670*0.1, 0.065*0.5 );
      // printf("    cmix %f R %f G %f B\n", 0.265*cmats[buf[j]-1][0], 0.670*cmats[buf[j]-1][1], 0.065*cmats[buf[j]-1][2] );
      // printf("    cmix %f R %f G %f B\n", 0.265*cmats[buf[j]-1][3], 0.670*cmats[buf[j]-1][4], 0.065*cmats[buf[j]-1][5] );
      // 
      #ifdef MGFX
      printf("    tf \"%s.ppm\"\n\n", splmats[this_mat_id-1]); // wir nehmen immer nur den 1. bzw. den 2. filenamen als material!!
      #endif
      #ifdef MGFRT
      printf("#   tf \"%s.ppm\"\n\n", splmats[this_mat_id-1]); // wir nehmen immer nur den 1. bzw. den 2. filenamen als material!!
      #endif
    }
    #endif
    if ( l == 1 ) printf("# single triangle supressed,since it's only used for in-game collision detection\n# "); // suppress triangles
    if ( KILL==1 ) printf("# LEVEL OF DETAIL suppressed!\n");
      mejo=i;
      #ifdef MGF
      for (k=0; k<l; k++)
      {
        for ( m=0; m<3 ; m++ )
        {
          vA = (int)(*(short int*)&buf[i]); i+=2;
          printf("v vert%d =\n", vA);
          printf("       p  %f %f %f\n", vertices[vA][0], vertices[vA][1], vertices[vA][2]);
          printf("       n  %f %f %f\n", vertices[vA][3], vertices[vA][4], vertices[vA][5]);

          #ifdef MGFRT
          printf("       tc %f %f\n", vertices[vA][6], vertices[vA][7] );
          #endif

          #ifdef MGFX
          printf("       tc %f %f %d\n", vertices[vA][6], vertices[vA][7], this_mat_id );
          #endif
        }
      }
      #endif
      i=mejo;
      #ifdef HACK
      printf("# output of faces ommitted (nobody wants to hack them anyway)\n");
      #endif
      for (k=0; k<l; k++)
      {
        #ifdef CRIPPLEOUT
        if ( k == 6 ) printf("# **** alles weitere wurde hier weggelassen...\n");
        if ( k < 6 ) // nur die ersten paar ausgeben...
        {
        #endif
        vA = (int)(*(short int*)&buf[i+ 0]);
        vB = (int)(*(short int*)&buf[i+ 2]);
        vC = (int)(*(short int*)&buf[i+ 4]);
        if ( KILL==1 ) printf("# ");
        #ifdef MGF
        printf("f vert%d vert%d vert%d\n", vA, vB, vC );
        #endif
        #ifdef OBJ
        vA+=globvert+1; vB+=globvert+1; vC+=globvert+1; // OBJs zaehlen die Vertices von 1 an ausserdem muessen noch die globverts draufaddiert werden!
        // printf("f %d/%d/%d %d/%d/%d %d/%d/%d\n", vC, vC, vC,   vB, vB, vB,   vA, vA, vA );
        printf("f %d/%d/%d %d/%d/%d %d/%d/%d\n", vA, vA, vA,   vB, vB, vB,   vC, vC, vC );
        #endif
        #ifdef CRIPPLEOUT
        }
        #endif
        i+=0x06; // every triangle consists of 3 short-ints describing the vertex-number
      }
    // oben schon gemacht: printf("\n# tri-material: %02x/%02x (%d)  [ %02x %02x @ %08x ]", buf[i], maxobj, buf[i],  buf[i], buf[i+1], i); 
    // if ( buf[i] == 0      ) printf(" -ERROR?- Material is zero!");      //  material 0: vermutlich collision-detection dreieck!
    // if ( buf[i] >= maxobj ) printf(" -ERROR?- Material out of range!"); //  oder die materialien zaehlen ab 1, dann muss buf<=maxobj und buf>0 sein!
    printf("\n\n");
    i+=2; // material ueberlesen
    nf++;
   }

   globvert+=merke;

   obj++;

   aLOD++;

   } // while aLOD < LODcount

   KILL=0; // KILL zuruecksetzen

   return(i);
}
#else
int VERTEX_AREA(int start) // gvv
{
   int j, k, l, merke, subtype, i, nf, loop;
   float x,y,z; unsigned short int vA, vB, vC;
   double mat[4][4]; double tvx, tvy, tvz, twx, twy, twz, txx, txy, txz, tyy, tyz, tzz; // fuer die quaternionen-rechnung
   double nat[16]; double xx,xy,xz,xw, yy,yz,yw, zz,zw; // Quaternionen-Mathe V2
   double nx, ny, nz;
   
   float ftx, fty, ftz, fsx, fsy, fsz, fftx, ffty, fftz; // temporaer modifizierte translation und skalierung
   int das_i, das_nf, znf, kuh_mat; // Merken fuer VRML2
   float u, v;

   i=start;
    // find the material and texture:
    l=(int)buf[i]+256*(int)buf[i+1]; i+=2; // number of vertices in block
    i+=l*0x20; // every vertice-set consists of 8 floats: x, y, z, nx, ny, nz, u, v
    subtype = buf[i]; i++; // printf("\n# triangle-blocks: %02x @ %08x\n", subtype,i); i++; 
    l=(int)buf[i]+256*(int)buf[i+1]; i+=2; // number of triangles in block
    i+=l*6;
    kuh_mat = i;
    printf("# pre-read: tri-material: %02x/%02x (%d)  [ %02x %02x @ %08x ]\n\n", buf[kuh_mat], maxobj, buf[kuh_mat],  buf[kuh_mat], buf[kuh_mat+1], kuh_mat); 

    i=start;
    //
   printf("\n# Vertex-Area %d @ %08x\n\n", obj, i); 
    printf("DEF %s-lod%d Transform {\n", this_mat, lod); robj++; // Objekt-Kennung
    printf("   children [\n");
    printf("   Shape {\n");
    printf("     appearance Appearance {\n");
    if ( ( buf[kuh_mat]==0 ) || ( mats[buf[kuh_mat]-1][0]==0 ) ) printf("         # no texture!\n"); else
    #ifdef VRML2RT
    printf("         texture ImageTexture { url \"%s.ppm\" }\n", splmats[buf[kuh_mat]-1] );
    #else
    printf("         texture ImageTexture { url \"%s\" }\n", mats[buf[kuh_mat]-1] );
    #endif
    printf("         material Material {\n");
    printf("            diffuseColor 0.6784 0.6784 0.6784\n");
    printf("            ambientIntensity 0.1985\n");
    printf("            specularColor 0.045 0.045 0.045\n");
    printf("         }\n");
    printf("     }\n");
    printf("     geometry IndexedFaceSet {\n");
    printf("           ccw FALSE\n");
    printf("           solid TRUE\n");
    printf("           coord Coordinate { point [\n");

   l=(int)buf[i]+256*(int)buf[i+1]; i+=2; // number of vertices in block
   printf("# Number of vertices in block: %d [%04x]\n", l, l);
   das_i = i; // Merken fuer VRML2
   for (k=0; k<l; k++)
   {
     // Rotiere die Koordinaten um 180Grad um die X-Achse: x=x, y=-y, z=-z
     x=*(float*)&buf[i+ 0]; y=*(float*)&buf[i+ 4]; z=*(float*)&buf[i+ 8];

     // TIP: Mafia Quaternionen sind Union-Quaternionen!   rx^2 + ry^2 + rz^2 + rw^2 = 1.0
     // This stuff is highly unoptimized. But who cares, as long as it's still fast enough and works!
      xx      = rx * rx; xy      = rx * ry; xz      = rx * rz; xw      = rx * rw;
      yy      = ry * ry; yz      = ry * rz; yw      = ry * rw; 
      zz      = rz * rz; zw      = rz * rw; 
      nat[0]  = 1 - 2 * ( yy + zz ); nat[1]  =     2 * ( xy - zw ); nat[2]  =     2 * ( xz + yw );
      nat[4]  =     2 * ( xy + zw ); nat[5]  = 1 - 2 * ( xx + zz ); nat[6]  =     2 * ( yz - xw );
      nat[8]  =     2 * ( xz - yw ); nat[9]  =     2 * ( yz + xw ); nat[10] = 1 - 2 * ( xx + yy );
      nat[3]  = 0; nat[7]  = 0; nat[11] = 0; nat[12] = 0; nat[13] = 0; nat[14] = 0; nat[15] = 1;

      // this document
      mat[0][0] = nat[0]; mat[0][1] = nat[1]; mat[0][2] = nat[2];
      mat[1][0] = nat[4]; mat[1][1] = nat[5]; mat[1][2] = nat[6];
      mat[2][0] = nat[8]; mat[2][1] = nat[9]; mat[2][2] = nat[10];

     // spiegeln:
     // if ( mirror == 0 )  -- identitaet --
     if ( mirror == 1 ) { x = -x;                   }
     if ( mirror == 2 ) {          y = -y;          }
     if ( mirror == 3 ) {                   z = -z; }
     if ( mirror == 4 ) { x = -x;  y = -y;          }
     if ( mirror == 5 ) {          y = -y;  z = -z; }
     if ( mirror == 6 ) { x = -x;           z = -z; }
     if ( mirror == 7 ) { x = -x;  y = -y;  z = -z; }

     // vertauschen
     if ( twist == 0 ) { nx = x; ny = y; nz = z; }
     if ( twist == 1 ) { nx = x; ny = z; nz = y; }
     if ( twist == 2 ) { nx = y; ny = x; nz = z; }
     if ( twist == 3 ) { nx = y; ny = z; nz = x; }
     if ( twist == 4 ) { nx = z; ny = x; nz = y; }
     if ( twist == 5 ) { nx = z; ny = y; nz = x; }

     x = nx; y = ny; z = nz;
     nx = mat[0][0]*x+mat[0][1]*y+mat[0][2]*z; ny = mat[1][0]*x+mat[1][1]*y+mat[1][2]*z; nz = mat[2][0]*x+mat[2][1]*y+mat[2][2]*z;
     x = nx; y = ny; z = nz;

     // spiegeln:
     // if ( mirror2 == 0 )  -- identitaet --
     if ( mirror2 == 1 ) { x = -x;                   }
     if ( mirror2 == 2 ) {          y = -y;          }
     if ( mirror2 == 3 ) {                   z = -z; }
     if ( mirror2 == 4 ) { x = -x;  y = -y;          }
     if ( mirror2 == 5 ) {          y = -y;  z = -z; }
     if ( mirror2 == 6 ) { x = -x;           z = -z; }
     if ( mirror2 == 7 ) { x = -x;  y = -y;  z = -z; }

     // vertauschen
     if ( twist2 == 0 ) { nx = x; ny = y; nz = z; }
     if ( twist2 == 1 ) { nx = x; ny = z; nz = y; }
     if ( twist2 == 2 ) { nx = y; ny = x; nz = z; }
     if ( twist2 == 3 ) { nx = y; ny = z; nz = x; }
     if ( twist2 == 4 ) { nx = z; ny = x; nz = y; }
     if ( twist2 == 5 ) { nx = z; ny = y; nz = x; }

     x = nx * sx + tx; y = ny * sy + ty; z = nz * sz + tz; // translate and scale after rotation * THE BEST *

     if ( k==(l-1) ) printf("           %f %f %f ]\n           }\n", -x, y, z); 
               else  printf("           %f %f %f,\n", -x, y, z);

     i+=0x20; // every vertice-set consists of 8 floats: x, y, z, nx, ny, nz, u, v
   }
   merke=l; // store number of vertices 

   printf("           normal Normal { vector [\n");
   i=das_i;
   for (k=0; k<l; k++)
   {
     // TIP: Mafia Quaternionen sind Union-Quaternionen!   rx^2 + ry^2 + rz^2 + rw^2 = 1.0
     // This stuff is highly unoptimized. But who cares, as long as it's still fast enough and works!
      xx      = rx * rx; xy      = rx * ry; xz      = rx * rz; xw      = rx * rw;
      yy      = ry * ry; yz      = ry * rz; yw      = ry * rw; 
      zz      = rz * rz; zw      = rz * rw; 
      nat[0]  = 1 - 2 * ( yy + zz ); nat[1]  =     2 * ( xy - zw ); nat[2]  =     2 * ( xz + yw );
      nat[4]  =     2 * ( xy + zw ); nat[5]  = 1 - 2 * ( xx + zz ); nat[6]  =     2 * ( yz - xw );
      nat[8]  =     2 * ( xz - yw ); nat[9]  =     2 * ( yz + xw ); nat[10] = 1 - 2 * ( xx + yy );
      nat[3]  = 0; nat[7]  = 0; nat[11] = 0; nat[12] = 0; nat[13] = 0; nat[14] = 0; nat[15] = 1;

      // this document
      mat[0][0] = nat[0]; mat[0][1] = nat[1]; mat[0][2] = nat[2];
      mat[1][0] = nat[4]; mat[1][1] = nat[5]; mat[1][2] = nat[6];
      mat[2][0] = nat[8]; mat[2][1] = nat[9]; mat[2][2] = nat[10];

      x=*(float*)&buf[i+12]; y= *(float*)&buf[i+16]; z=*(float*)&buf[i+20]; // das sind die NORMALEN!!
     // spiegeln:
     // if ( mirror == 0 )  -- identitaet --
     if ( mirror == 1 ) { x = -x;                   }
     if ( mirror == 2 ) {          y = -y;          }
     if ( mirror == 3 ) {                   z = -z; }
     if ( mirror == 4 ) { x = -x;  y = -y;          }
     if ( mirror == 5 ) {          y = -y;  z = -z; }
     if ( mirror == 6 ) { x = -x;           z = -z; }
     if ( mirror == 7 ) { x = -x;  y = -y;  z = -z; }

     // vertauschen
     if ( twist == 0 ) { nx = x; ny = y; nz = z; }
     if ( twist == 1 ) { nx = x; ny = z; nz = y; }
     if ( twist == 2 ) { nx = y; ny = x; nz = z; }
     if ( twist == 3 ) { nx = y; ny = z; nz = x; }
     if ( twist == 4 ) { nx = z; ny = x; nz = y; }
     if ( twist == 5 ) { nx = z; ny = y; nz = x; }

     x = nx; y = ny; z = nz;
     nx = mat[0][0]*x+mat[0][1]*y+mat[0][2]*z; ny = mat[1][0]*x+mat[1][1]*y+mat[1][2]*z; nz = mat[2][0]*x+mat[2][1]*y+mat[2][2]*z;
     x = nx; y = ny; z = nz;

     // spiegeln:
     // if ( mirror2 == 0 )  -- identitaet --
     if ( mirror2 == 1 ) { x = -x;                   }
     if ( mirror2 == 2 ) {          y = -y;          }
     if ( mirror2 == 3 ) {                   z = -z; }
     if ( mirror2 == 4 ) { x = -x;  y = -y;          }
     if ( mirror2 == 5 ) {          y = -y;  z = -z; }
     if ( mirror2 == 6 ) { x = -x;           z = -z; }
     if ( mirror2 == 7 ) { x = -x;  y = -y;  z = -z; }

     // vertauschen
     if ( twist2 == 0 ) { nx = x; ny = y; nz = z; }
     if ( twist2 == 1 ) { nx = x; ny = z; nz = y; }
     if ( twist2 == 2 ) { nx = y; ny = x; nz = z; }
     if ( twist2 == 3 ) { nx = y; ny = z; nz = x; }
     if ( twist2 == 4 ) { nx = z; ny = x; nz = y; }
     if ( twist2 == 5 ) { nx = z; ny = y; nz = x; }
     if ( k==(l-1) ) printf("           %f %f %f ]\n           }\n", -nx, ny, nz); else  printf("           %f %f %f,\n", -nx, ny, nz );
     i+=0x20; // every vertice-set consists of 8 floats: x, y, z, nx, ny, nz, u, v
   }
   // printf("           normalPerVertex TRUE\n");
   printf("           texCoord TextureCoordinate { point [\n");
   i=das_i;
   for (k=0; k<l; k++)
   {
     u = *(float*)&buf[i+24]; v = -*(float*)&buf[i+28];
     if ( k==(l-1) ) printf("           %f %f ]\n           }\n", u, v);
               else  printf("           %f %f,\n", u, v );
     i+=0x20; // every vertice-set consists of 8 floats: x, y, z, nx, ny, nz, u, v
   }

   nf=0; subtype = buf[i]; printf("\n# triangle-blocks: %02x @ %08x\n", subtype,i); i++; 

   das_nf = subtype; // while (nf<subtype)
   // den ersten durchlauf gibts immer!
    l=(int)buf[i]+256*(int)buf[i+1]; i+=2; // number of triangles in block
    printf("# Number of triangles in block %d = %d [ %04x @ %08x ]\n", nf, l, l, i);
    j=i+l*6;
    printf("# pre-read [COR]: tri-material: %02x/%02x (%d)  [ %02x %02x @ %08x ]\n\n", buf[j], maxobj, buf[j],  buf[j], buf[j+1], j); 
    if ( l == 1 ) printf("# single triangle supressed,since it's only used for in-game collision detection\n# "); // suppress triangles
    if ( KILL==1 ) printf("# LEVEL OF DETAIL suppressed!\n");
      if ( KILL==1 ) printf("# ");
      printf("           coordIndex [\n");
      for (k=0; k<l; k++)
      {
        vA = *(short int*)&buf[i+ 0];
        vB = *(short int*)&buf[i+ 2];
        vC = *(short int*)&buf[i+ 4];
        if ( KILL==1 ) printf("# ");
      if ( k==(l-1) ) printf("           %d %d %d -1]\n", vA, vB, vC );
                else  printf("           %d %d %d -1,\n", vA, vB, vC );
      i+=0x06; // every triangle consists of 3 short-ints describing the vertex-number
    }
    printf("\n\n");
    i+=2; // material ueberlesen

    printf("     }\n");  //  geometry IndexedFaceSet - schliessen
    printf("   }\n");  //  Transform-Knoten schliessen
    printf(" ]\n");  // children schliessen
    printf("}\n");  //  Transform-Knoten schliessen

   // erster durchlauf zuende
   //
   // beginne mit den weiteren durchlaeufen
   nf = 1; while ( nf < das_nf )
   {
   i=start;
   printf("\n# Vertex-Area %d @ %08x\n\n", obj, i); 

    // find the material and texture:
    l=(int)buf[i]+256*(int)buf[i+1]; i+=2; // number of vertices in block
    i+=l*0x20; // every vertice-set consists of 8 floats: x, y, z, nx, ny, nz, u, v
    subtype = buf[i]; i++; // printf("\n# triangle-blocks: %02x @ %08x\n", subtype,i); i++; 
    znf=0; while ( znf <= nf )
    {
      l=(int)buf[i]+256*(int)buf[i+1]; i+=2; // number of triangles in block
      i+=l*6;
      kuh_mat = i;
      i+=2; // material ueberlesen
      znf++;
    }
    printf("# pre-read: tri-material: %02x/%02x (%d)  [ %02x %02x @ %08x ]\n\n", buf[kuh_mat], maxobj, buf[kuh_mat],  buf[kuh_mat], buf[kuh_mat+1], kuh_mat); 
    i=start;
    //
    printf("DEF %s-lod%d-%d Transform {\n", this_mat, lod, nf); robj++; // Objekt-Kennung
    printf("   children [\n");
    printf("   Shape {\n");
    printf("     appearance Appearance {\n");
    if ( ( buf[kuh_mat]==0 ) || ( mats[buf[kuh_mat]-1][0]==0 ) ) printf("         # no texture!\n"); else
    #ifdef VRML2RT
    printf("         texture ImageTexture { url \"%s.ppm\" }\n", splmats[buf[kuh_mat]-1] );
    #else
    printf("         texture ImageTexture { url \"%s\" }\n", mats[buf[kuh_mat]-1] );
    #endif
    printf("         material Material {\n");
    printf("            diffuseColor 0.8 0.8 0.8\n");
    printf("            ambientIntensity 0.5\n");
    printf("            specularColor 0.4 0.4 0.35\n");
    printf("         }\n");
    printf("     }\n");
    printf("     geometry IndexedFaceSet {\n");
    printf("           ccw FALSE\n");
    printf("           solid TRUE\n");
    printf("           coord Coordinate { point [\n");

   l=(int)buf[i]+256*(int)buf[i+1]; i+=2; // number of vertices in block
   printf("# Number of vertices in block: %d [%04x]\n", l, l);
   das_i = i; // Merken fuer VRML2
   for (k=0; k<l; k++)
   {
     // Rotiere die Koordinaten um 180Grad um die X-Achse: x=x, y=-y, z=-z
     x=*(float*)&buf[i+ 0]; y=*(float*)&buf[i+ 4]; z=*(float*)&buf[i+ 8];

     // TIP: Mafia Quaternionen sind Union-Quaternionen!   rx^2 + ry^2 + rz^2 + rw^2 = 1.0
     // This stuff is highly unoptimized. But who cares, as long as it's still fast enough and works!
      xx      = rx * rx; xy      = rx * ry; xz      = rx * rz; xw      = rx * rw;
      yy      = ry * ry; yz      = ry * rz; yw      = ry * rw; 
      zz      = rz * rz; zw      = rz * rw; 
      nat[0]  = 1 - 2 * ( yy + zz ); nat[1]  =     2 * ( xy - zw ); nat[2]  =     2 * ( xz + yw );
      nat[4]  =     2 * ( xy + zw ); nat[5]  = 1 - 2 * ( xx + zz ); nat[6]  =     2 * ( yz - xw );
      nat[8]  =     2 * ( xz - yw ); nat[9]  =     2 * ( yz + xw ); nat[10] = 1 - 2 * ( xx + yy );
      nat[3]  = 0; nat[7]  = 0; nat[11] = 0; nat[12] = 0; nat[13] = 0; nat[14] = 0; nat[15] = 1;

      // this document
      mat[0][0] = nat[0]; mat[0][1] = nat[1]; mat[0][2] = nat[2];
      mat[1][0] = nat[4]; mat[1][1] = nat[5]; mat[1][2] = nat[6];
      mat[2][0] = nat[8]; mat[2][1] = nat[9]; mat[2][2] = nat[10];

     // spiegeln:
     // if ( mirror == 0 )  -- identitaet --
     if ( mirror == 1 ) { x = -x;                   }
     if ( mirror == 2 ) {          y = -y;          }
     if ( mirror == 3 ) {                   z = -z; }
     if ( mirror == 4 ) { x = -x;  y = -y;          }
     if ( mirror == 5 ) {          y = -y;  z = -z; }
     if ( mirror == 6 ) { x = -x;           z = -z; }
     if ( mirror == 7 ) { x = -x;  y = -y;  z = -z; }

     // vertauschen
     if ( twist == 0 ) { nx = x; ny = y; nz = z; }
     if ( twist == 1 ) { nx = x; ny = z; nz = y; }
     if ( twist == 2 ) { nx = y; ny = x; nz = z; }
     if ( twist == 3 ) { nx = y; ny = z; nz = x; }
     if ( twist == 4 ) { nx = z; ny = x; nz = y; }
     if ( twist == 5 ) { nx = z; ny = y; nz = x; }

     x = nx; y = ny; z = nz;
     nx = mat[0][0]*x+mat[0][1]*y+mat[0][2]*z; ny = mat[1][0]*x+mat[1][1]*y+mat[1][2]*z; nz = mat[2][0]*x+mat[2][1]*y+mat[2][2]*z;
     x = nx; y = ny; z = nz;

     // spiegeln:
     // if ( mirror2 == 0 )  -- identitaet --
     if ( mirror2 == 1 ) { x = -x;                   }
     if ( mirror2 == 2 ) {          y = -y;          }
     if ( mirror2 == 3 ) {                   z = -z; }
     if ( mirror2 == 4 ) { x = -x;  y = -y;          }
     if ( mirror2 == 5 ) {          y = -y;  z = -z; }
     if ( mirror2 == 6 ) { x = -x;           z = -z; }
     if ( mirror2 == 7 ) { x = -x;  y = -y;  z = -z; }

     // vertauschen
     if ( twist2 == 0 ) { nx = x; ny = y; nz = z; }
     if ( twist2 == 1 ) { nx = x; ny = z; nz = y; }
     if ( twist2 == 2 ) { nx = y; ny = x; nz = z; }
     if ( twist2 == 3 ) { nx = y; ny = z; nz = x; }
     if ( twist2 == 4 ) { nx = z; ny = x; nz = y; }
     if ( twist2 == 5 ) { nx = z; ny = y; nz = x; }

     x = nx * sx + tx; y = ny * sy + ty; z = nz * sz + tz; // translate and scale after rotation * THE BEST *

     if ( k==(l-1) ) printf("           %f %f %f ]\n           }\n", -x, y, z); 
               else  printf("           %f %f %f,\n", -x, y, z);

     i+=0x20; // every vertice-set consists of 8 floats: x, y, z, nx, ny, nz, u, v
   }
   merke=l; // store number of vertices 

   printf("           normal Normal { vector [\n");
   i=das_i;
   for (k=0; k<l; k++)
   {
     // TIP: Mafia Quaternionen sind Union-Quaternionen!   rx^2 + ry^2 + rz^2 + rw^2 = 1.0
     // This stuff is highly unoptimized. But who cares, as long as it's still fast enough and works!
      xx      = rx * rx; xy      = rx * ry; xz      = rx * rz; xw      = rx * rw;
      yy      = ry * ry; yz      = ry * rz; yw      = ry * rw; 
      zz      = rz * rz; zw      = rz * rw; 
      nat[0]  = 1 - 2 * ( yy + zz ); nat[1]  =     2 * ( xy - zw ); nat[2]  =     2 * ( xz + yw );
      nat[4]  =     2 * ( xy + zw ); nat[5]  = 1 - 2 * ( xx + zz ); nat[6]  =     2 * ( yz - xw );
      nat[8]  =     2 * ( xz - yw ); nat[9]  =     2 * ( yz + xw ); nat[10] = 1 - 2 * ( xx + yy );
      nat[3]  = 0; nat[7]  = 0; nat[11] = 0; nat[12] = 0; nat[13] = 0; nat[14] = 0; nat[15] = 1;

      // this document
      mat[0][0] = nat[0]; mat[0][1] = nat[1]; mat[0][2] = nat[2];
      mat[1][0] = nat[4]; mat[1][1] = nat[5]; mat[1][2] = nat[6];
      mat[2][0] = nat[8]; mat[2][1] = nat[9]; mat[2][2] = nat[10];

      x=*(float*)&buf[i+12]; y= *(float*)&buf[i+16]; z=*(float*)&buf[i+20]; // das sind die NORMALEN!!
     // spiegeln:
     // if ( mirror == 0 )  -- identitaet --
     if ( mirror == 1 ) { x = -x;                   }
     if ( mirror == 2 ) {          y = -y;          }
     if ( mirror == 3 ) {                   z = -z; }
     if ( mirror == 4 ) { x = -x;  y = -y;          }
     if ( mirror == 5 ) {          y = -y;  z = -z; }
     if ( mirror == 6 ) { x = -x;           z = -z; }
     if ( mirror == 7 ) { x = -x;  y = -y;  z = -z; }

     // vertauschen
     if ( twist == 0 ) { nx = x; ny = y; nz = z; }
     if ( twist == 1 ) { nx = x; ny = z; nz = y; }
     if ( twist == 2 ) { nx = y; ny = x; nz = z; }
     if ( twist == 3 ) { nx = y; ny = z; nz = x; }
     if ( twist == 4 ) { nx = z; ny = x; nz = y; }
     if ( twist == 5 ) { nx = z; ny = y; nz = x; }

     x = nx; y = ny; z = nz;
     nx = mat[0][0]*x+mat[0][1]*y+mat[0][2]*z; ny = mat[1][0]*x+mat[1][1]*y+mat[1][2]*z; nz = mat[2][0]*x+mat[2][1]*y+mat[2][2]*z;
     x = nx; y = ny; z = nz;

     // spiegeln:
     // if ( mirror2 == 0 )  -- identitaet --
     if ( mirror2 == 1 ) { x = -x;                   }
     if ( mirror2 == 2 ) {          y = -y;          }
     if ( mirror2 == 3 ) {                   z = -z; }
     if ( mirror2 == 4 ) { x = -x;  y = -y;          }
     if ( mirror2 == 5 ) {          y = -y;  z = -z; }
     if ( mirror2 == 6 ) { x = -x;           z = -z; }
     if ( mirror2 == 7 ) { x = -x;  y = -y;  z = -z; }

     // vertauschen
     if ( twist2 == 0 ) { nx = x; ny = y; nz = z; }
     if ( twist2 == 1 ) { nx = x; ny = z; nz = y; }
     if ( twist2 == 2 ) { nx = y; ny = x; nz = z; }
     if ( twist2 == 3 ) { nx = y; ny = z; nz = x; }
     if ( twist2 == 4 ) { nx = z; ny = x; nz = y; }
     if ( twist2 == 5 ) { nx = z; ny = y; nz = x; }
     if ( k==(l-1) ) printf("           %f %f %f ]\n           }\n", -nx, ny, nz); else  printf("           %f %f %f,\n", -nx, ny, nz );
     i+=0x20; // every vertice-set consists of 8 floats: x, y, z, nx, ny, nz, u, v
   }
   // printf("           normalPerVertex TRUE\n");
   printf("           texCoord TextureCoordinate { point [\n");
   i=das_i;
   for (k=0; k<l; k++)
   {
     u = *(float*)&buf[i+24]; v = -*(float*)&buf[i+28];
     if ( k==(l-1) ) printf("           %f %f ]\n           }\n", u, v);
               else  printf("           %f %f,\n", u, v );
     i+=0x20; // every vertice-set consists of 8 floats: x, y, z, nx, ny, nz, u, v
   }

   subtype = buf[i]; printf("\n# triangle-blocks: %02x @ %08x\n", subtype,i); i++; 
   printf("# DAS_NF: %d / %d \n", nf, das_nf );

   znf = 0;
   while ( znf <= nf )
   {
    l=(int)buf[i]+256*(int)buf[i+1]; i+=2; // number of triangles in block
    printf("# Number of triangles in block %d = %d [ %04x @ %08x ]\n", nf, l, l, i);
    j=i+l*6;
    printf("# pre-read [COR]: tri-material: %02x/%02x (%d)  [ %02x %02x @ %08x ]\n\n", buf[j], maxobj, buf[j],  buf[j], buf[j+1], j); 
    if ( l == 1 ) printf("# single triangle supressed,since it's only used for in-game collision detection\n# "); // suppress triangles
    if ( KILL==1 ) printf("# LEVEL OF DETAIL suppressed!\n");
      if ( znf == nf )
      {
       if ( KILL==1 ) printf("# ");
       printf("           coordIndex [\n");
      }
      for (k=0; k<l; k++)
      {
        vA = *(short int*)&buf[i+ 0];
        vB = *(short int*)&buf[i+ 2];
        vC = *(short int*)&buf[i+ 4];
        if ( znf == nf )
        {
           if ( KILL==1 ) printf("# ");
           if ( k==(l-1) ) printf("           %d %d %d -1]\n", vA, vB, vC );
                    else  printf("           %d %d %d -1,\n", vA, vB, vC );
        }
      i+=0x06; // every triangle consists of 3 short-ints describing the vertex-number
    }
    printf("\n\n");
    i+=2; // material ueberlesen

    znf++;
   }

    nf++;

    printf("     }\n");  //  geometry IndexedFaceSet - schliessen
    printf("   }\n");  //  Transform-Knoten schliessen
    printf(" ]\n");  // children schliessen
    printf("}\n");  //  Transform-Knoten schliessen

   }
   


   obj++;

   KILL=0; // KILL zuruecksetzen

   return(i);
}
#endif


int main(int argc,char *argv[])
{
   // var_decl
   uint flen, otype;
   int i,j,k,l,m,x,y,raus,ja, bl, fn, subtype, merke, totalblocks, cublox;
   uint BI; float BF;

   float mat[4][4]; float tvx, tvy, tvz, twx, twy, twz, txx, txy, txz, tyy, tyz, tzz; // fuer die quaternionen-rechnung
   float nat[16]; float xx,xy,xz,xw, yy,yz,yw, zz,zw; // Quaternionen-Mathe V2
   float cos_a, sin_a, angle, axisx, axisy, axisz;
   float x1, x2, y1, y2, z1, z2, w1, w2, ox, oy, oz, ow;
   float omtx, omty, omtz, omsx, omsy, omsz, omrx, omry, omrz, omrw;

   // not yet implemented... for (i=0; i < MAXMATS; i++ ) this_mat_done[i]=0; // fuer den VRML2-Export

   // Current Commandline is very simple: if no arguments are given, the file scene.4ds in the current directory will be loaded
   //                                     on the other hand you can specify the file name to be loaded as the first parameter
   i=(int)(DATE/10000);
   j=(int)((DATE-i*10000)/100);
   k=(int)(DATE-i*10000-j*100);
   if (argc<2) 
   {
    #ifdef HACK
    savbuf[0]='t'; savbuf[1]='x'; savbuf[2]='t'; savbuf[3]=0; 
    #endif
    #ifdef OBJ
    savbuf[0]='o'; savbuf[1]='b'; savbuf[2]='j'; savbuf[3]=0; 
    #endif
    #ifdef MGF
    savbuf[0]='m'; savbuf[1]='g'; savbuf[2]='f'; savbuf[3]=0; 
    #endif
    #ifdef VRML2
    savbuf[0]='w'; savbuf[1]='r'; savbuf[2]='l'; savbuf[3]=0; 
    #endif
    printf("Mafia-ls V%4.2f                                jofis@saarcor.de, %02d.%02d.%02d\n", VNR, i, j, k);
    printf("Call: mafials <filename> [<kill lod objects>]\n");
    printf("Example1:    mafials.exe fordtTud00.4ds 1 > Ford00.%s\n", savbuf);
    printf("Example2:    mafials.exe FMVcad_road00.4ds 0 > FMCr00.%s\n", savbuf);
    printf("Example3:    mafials.exe 00menu/scene.4ds > 00menu.%s\n", savbuf);
    printf("Usage:  If <kill lod objects> is set (like in example1),\n");
    printf("        only the highest level of detail will be exported.\n");
    #ifdef VRML2
    printf("This binary has been compiled to output VRML2 files!\n");
    #ifdef DOS_MODE
    printf("\"mafcp.bat\" for copying the textures will be created in the current directory.\n");
    #else
    printf("\"mafcp.sh\" for copying the textures will be created in the current directory.\n");
    #endif
    #endif
    #ifdef OBJ
    printf("This binary has been compiled to output Wavefront OBJ files!\n");
    printf("The material-file \"mafls.mtl\" will be generated in the current directory!\n");
    #ifdef DOS_MODE
    printf("\"mafcp.bat\" for copying the textures will also be created here.\n");
    #else
    printf("\"mafcp.sh\" for copying the textures will also be created here.\n");
    #endif
    #endif
    #ifdef MGF
    #ifndef MGFX
    printf("This binary has been compiled to output MGF files!\n");
    printf("Shell-script \"mafcp.sh\" for copying the textures will also be created here.\n");
    #else
    printf("This binary has been compiled to output MGF+Sea files!\n");
    printf("Sea-file \"mafls.sea\" will be generated in the current directory!\n");
    printf("Shell-script \"mafcp.sh\" for copying the textures will also be created here.\n");
    #endif
    #endif
    #ifdef HACK
    printf("This binary has been compiled to output HACK ascii files!\n");
    #endif

    exit(1);
   } 
   scene4ds=argv[1];
   do_a_kill=0; if ( argc>2 ) { if (argv[2][0]=='1' ) do_a_kill=1; }
   
   twist = 5 ; mirror = 6 ; twist2 = 5 ; mirror2 = 4;  // THESE VALUES ARE _VERY_ IMPORTANT - SO DON'T CHANGE THEM!
   #if 0
   twist = 0; mirror = 0; twist2 = 0; mirror2 = 0;
   if (argc>2) { twist = argv[2][0] - 48 ; mirror = argv[2][1] - 48 ; twist2= argv[2][2] - 48 ; mirror2= argv[2][3] - 48 ; }
   printf("# \n# twist = %d    mirror = %d   twist2 = %d   mirror2 = %d\n# \n", twist, mirror, twist2, mirror2 );
   #endif


   //f_open
   #ifdef DOS_MODE
   handle=open(scene4ds,O_RDONLY|O_BINARY);
   #else
   handle=open(scene4ds,O_RDONLY);
   #endif
   if (fstat(handle,&staat)<0) {printf("ERROR occured opening the scene4ds-file!\n"); exit(1);}
   buf=(byte*)malloc((staat.st_size)+2); // Malloc!
   if (buf==0) {printf("ERROR allocating %d bytes of memory!\r\n",((staat.st_size)+2)); exit(1);}
   if (read(handle,buf,staat.st_size)<0) {printf("ERROR reading scene4ds-file!\r\n"); exit(1);}
   close(handle);
   flen=staat.st_size;

   #ifdef VRML2
   printf("#VRML V2.0 utf8\n\n\n");
   #endif

   #ifdef OBJ
   printf("mtllib mafls.mtl\n\n\n");
   #endif

   printf("# 4DS to OBJ/MGF converter v%4.2f (%02d.%02d.%02d), jofis@saarcor.de\n", VNR, i,j,k);
   printf("# \n");
   printf("# Name of Scene-File: %s\n", scene4ds);
   printf("# \n");

   #ifdef TRANSFORM_AND_SCALE
   printf("# NOTE: all vertex coordinates will be transformed and scaled before exporting!\n");
   #else
   printf("# NOTE: all vertex coordinates will be exported as is (without transformation and scaling)\n");
   #endif

   if ( do_a_kill == 1 ) printf("# \n# NOTE: All levels of detail below \"high\"-level will not be exported!\n# \n");
                    else printf("# \n# NOTE: All levels of detail will be exported,\n# so several objects might be at the same position.\n# \n");


   // --------------------------------------------------------------- HEADER - MODE ----------------------------------------------------
  
   printf("# HEADER:\n"); printhex(0x00, 0x10); printf("\n");
   maxobj = buf[14]+256*buf[15]; // Anzahl Objekte im Scene.4ds-File
   if ( maxobj > MAXMATS ) { printf("*** ERROR *** MAXMATS lower then number of materials in this file!\nplease increment the #define and recompile!\n"); exit(0);}
   raus=1; i=0x10; obj=0; 
   while (raus!=0)
   {
     ja = 0;
     otype = (((uint)buf[i]<<24)+((uint)buf[i+1]<<16)+((uint)buf[i+2]<<8)+(uint)buf[i+3]);

     // decoding what is presumed to be a type-specification into  "bl" the block-length, and "fn" the number of filenames specified in that block

     if (otype == 0x01000000 ) { ja = 1; bl = 0x2c; fn = 0; }
     if (otype == 0x01008000 ) { ja = 1; bl = 0x2c; fn = 0; }

     if (otype == 0x01000010 ) { ja = 1; bl = 0x2c; fn = 1; }
     if (otype == 0x01000400 ) { ja = 1; bl = 0x2c; fn = 1; }
     if (otype == 0x01000600 ) { ja = 1; bl = 0x2c; fn = 1; }
     if (otype == 0x01002404 ) { ja = 1; bl = 0x2c; fn = 1; } 
     if (otype == 0x01008400 ) { ja = 1; bl = 0x2c; fn = 1; }
     if (otype == 0x01008600 ) { ja = 1; bl = 0x2c; fn = 1; }
     if (otype == 0x0100a400 ) { ja = 1; bl = 0x2c; fn = 1; }
     if (otype == 0x01800010 ) { ja = 1; bl = 0x2c; fn = 1; }
     if (otype == 0x01800404 ) { ja = 1; bl = 0x2c; fn = 1; } 
     if (otype == 0x01800420 ) { ja = 1; bl = 0x2c; fn = 1; }
     if (otype == 0x01800430 ) { ja = 1; bl = 0x2c; fn = 1; }
     if (otype == 0x01800520 ) { ja = 1; bl = 0x2c; fn = 1; }
     if (otype == 0x01808400 ) { ja = 1; bl = 0x2c; fn = 1; }
     if (otype == 0x01808420 ) { ja = 1; bl = 0x2c; fn = 1; }
     if (otype == 0x01808430 ) { ja = 1; bl = 0x2c; fn = 1; }
     if (otype == 0x01808480 ) { ja = 1; bl = 0x2c; fn = 1; }
     if (otype == 0x0180a480 ) { ja = 1; bl = 0x2c; fn = 1; }

     if (otype == 0x01800440 ) { ja = 1; bl = 0x2c; fn = 2; }
     if (otype == 0x01800446 ) { ja = 1; bl = 0x2c; fn = 2; }
     if (otype == 0x01808440 ) { ja = 1; bl = 0x2c; fn = 2; }
     if (otype == 0x01808450 ) { ja = 1; bl = 0x2c; fn = 2; }

     if (otype == 0x01848810 ) { ja = 1; bl = 0x30; fn = 2; }


     if (otype == 0x01010c00 ) { ja = 1; bl = 0x30; fn = 2; }
     if (otype == 0x01018c00 ) { ja = 1; bl = 0x30; fn = 2; }
     if (otype == 0x0101ac04 ) { ja = 1; bl = 0x30; fn = 2; }
     if (otype == 0x01040c00 ) { ja = 1; bl = 0x30; fn = 2; }
     if (otype == 0x01048c00 ) { ja = 1; bl = 0x30; fn = 2; }
     if (otype == 0x01058c00 ) { ja = 1; bl = 0x30; fn = 2; }
     if (otype == 0x01118c00 ) { ja = 1; bl = 0x30; fn = 2; }
     if (otype == 0x01830c80 ) { ja = 1; bl = 0x30; fn = 2; }


     if (otype == 0x01848c40 ) { ja = 1; bl = 0x30; fn = 3; }
     if (otype == 0x01858c40 ) { ja = 1; bl = 0x30; fn = 3; }
     if (otype == 0x01918c40 ) { ja = 1; bl = 0x30; fn = 3; }

     if (otype == 0x01950800 ) { ja = 1; bl = 0x30; fn = 2; } 

     if (otype == 0x14000000 ) { ja = 1; bl = 0x11; fn = 0; obj--; } // seltsam, wozu das wohl gut ist?? [missions/freekrajina/scene.4ds]
     if (otype == 0x1e010000 ) { ja = 1; bl = 0x11; fn = 0; obj--; } // seltsam, wozu das wohl gut ist?? [models/morezk1.4ds]

     if ( ja == 1 ) // block-type "successfully" decoded --> executing it!
     {
      printf("# Pos: %08x   type: %08x   material: %04x/%04x (%d)\n",i, otype, obj, maxobj, maxobj); 
      k=0;
      if ( bl == 0x2c )
      {
       k=1;
       i+=4; // type ueberlesen
       cmats[obj][0]=*(float*)&buf[i+0];
       cmats[obj][1]=*(float*)&buf[i+4];
       cmats[obj][2]=*(float*)&buf[i+8];
       printf("# ambient: "); printrfloats(3,i); i+=3*4;
       cmats[obj][3]=*(float*)&buf[i+0];
       cmats[obj][4]=*(float*)&buf[i+4];
       cmats[obj][5]=*(float*)&buf[i+8];
       printf("# diffuse: "); printrfloats(3,i); i+=3*4;
       cmats[obj][6]=*(float*)&buf[i+0];
       cmats[obj][7]=*(float*)&buf[i+4];
       cmats[obj][8]=*(float*)&buf[i+8];
       printf("# emissive: "); printrfloats(3,i); i+=3*4;
       cmats[obj][9]=*(float*)&buf[i+0];
       printf("# spare  "); printrfloats(1,i); i+=1*4;
      }
      if ( bl == 0x30 )
      {
       k=1;
       i+=4; // type ueberlesen
       cmats[obj][0]=*(float*)&buf[i+0];
       cmats[obj][1]=*(float*)&buf[i+4];
       cmats[obj][2]=*(float*)&buf[i+8];
       printf("# ambient: "); printrfloats(3,i); i+=3*4;
       cmats[obj][3]=*(float*)&buf[i+0];
       cmats[obj][4]=*(float*)&buf[i+4];
       cmats[obj][5]=*(float*)&buf[i+8];
       printf("# diffuse: "); printrfloats(3,i); i+=3*4;
       cmats[obj][6]=*(float*)&buf[i+0];
       cmats[obj][7]=*(float*)&buf[i+4];
       cmats[obj][8]=*(float*)&buf[i+8];
       printf("# emissive: "); printrfloats(3,i); i+=3*4;
       cmats[obj][9]=*(float*)&buf[i+0];
       printf("# spare1 "); printrfloats(1,i); i+=1*4;
       printf("# spare2 "); printrfloats(1,i); i+=1*4;
      }
      if ( k == 0 )
      {
        printhex(i, i+bl); i=i+bl;
      }
      k=buf[i]; // laenge des filename
      i++;
      if ( fn >= 1 )
      {
       #ifdef HACK
       printf("# %08x --> Filename1[%02x] = ",i, k); 
       #else
       printf("# Filename1[%02x] = ", k); 
       #endif
       for (j=0; j<k; j++) mats[obj][j]=buf[j+i]; mats[obj][k]=0; printf("%s\n", mats[obj]); // wir nehmen immer nur den 1. filenamen als material!!
       j=0; m=0; while (mats[obj][j]!=0) { if ( mats[obj][j]!=32 ) splmats[obj][m++]=mats[obj][j]; j++; } splmats[obj][m]=0; // generate Spaceless-Filename 
       i=i+k;
      }
      if ( fn >= 2 )
      {
       k=buf[i]; // laenge des filename
       i++;
       #ifdef HACK
       printf("# %08x --> Filename2[%02x] = ",i, k); 
       #else
       printf("# Filename2[%02x] = ", k); 
       #endif
       for (j=0; j<k; j++) mats[obj][j]=buf[j+i]; mats[obj][k]=0; printf("%s\n", mats[obj]); // wenn's mehr als einen filenamen gibt, dann nehmen wir den 2.
       j=0; m=0; while (mats[obj][j]!=0) { if ( mats[obj][j]!=32 ) splmats[obj][m++]=mats[obj][j]; j++; } splmats[obj][m]=0; // generate Spaceless-Filename 
       i=i+k;
      }
      if ( fn >= 3 )
      {
       k=buf[i]; // laenge des filename
       i++;
       #ifdef HACK
       printf("# %08x --> Filename3[%02x] = ",i, k); 
       #else
       printf("# Filename3[%02x] = ", k); 
       #endif
       for (j=0; j<k; j++) printf("%c",buf[j+i]); 
       i=i+k;
       printf("\n");
      }

      obj++;
      if ( obj == maxobj ) { printf("\n\n# all objects read -- entering vertice-block mode\n"); raus=0; }
     }


     if ( ja == 0 ) // kenne den Header noch nicht!!
     {
      printf("\nPos: %08x   type: %08x   **UNKNOWN TYPE!!**\n\n",i, otype); 
      printhex(i+0x00, i+0x10);
      printhex(i+0x10, i+0x20);
      printhex(i+0x20, i+0x30);
      printhex(i+0x30, i+0x40);
      printhex(i+0x40, i+0x50);
      printhex(i+0x50, i+0x60);
      printhex(i+0x60, i+0x70);
      printhex(i+0x70, i+0x80);
      printhex(i+0x80, i+0x90);
      printhex(i+0x90, i+0xa0);
      printhex(i+0xa0, i+0xb0);
      printhex(i+0xb0, i+0xc0);
      printhex(i+0xc0, i+0xd0);
      printhex(i+0xd0, i+0xe0);
      printhex(i+0xe0, i+0xf0);
      printhex(i+0xf0, i+0x100);
      raus=0;
     }
    
     printf("\n");
   }

   #ifdef MGF
     printf("c R =\n    cxy 0.640 0.330\n");
     printf("c G =\n    cxy 0.290 0.600\n");
     printf("c B =\n    cxy 0.150 0.060\n");
   #endif

   // --------------------------------------------------------------- VERTEX - BLOCK - MODE --------------------------------------------

   // Auf zu den Vertice-Bloecken
   obj=0; raus=0; ja=1; globvert=0; robj=0; lod=0; init_trans=1;
   tx=0; ty=0; tz=0; sx=1; sy=1; sz=1; rx=0; ry=0; rz=0; rw=0;
   mtx=0; mty=0; mtz=0; msx=1; msy=1; msz=1; mrx=1; mry=0; mrz=0; mrw=0;
   totalblocks = (int)buf[i]+256*(int)buf[i+1]; i+=2; cublox=0;
   printf("# \n# total blocks in file = %04x ( %d )\n# \n", totalblocks, totalblocks);
   if ( MAXBLOX < totalblocks ) { printf("*** ERROR *** MAXBLOX lower then number of blocks in this file!\nplease increment the #define and recompile!\n"); exit(0);}
   //
   // init transformation[0]: this is the neutral transformation
   trafo[0][0]=0.0; trafo[0][1]=0.0; trafo[0][2]=0.0; // transformation[0]: translation x,y,z
   trafo[0][3]=1.0; trafo[0][4]=1.0; trafo[0][5]=1.0; // transformation[0]: scale x,y,z
   trafo[0][6]=1.0; trafo[0][7]=0.0; trafo[0][8]=0.0; trafo[0][9]=0.0; // transformation[0]: quaternion x,y,z,w
   trafref[0]=-1; traftype[0]=-1;
   //
   while ((raus==0)&&((i+8)<=flen)) //i+8, weil in 8 bytes sowieso nix sinnvolles mehr drin stehen kann!
   {
     ja=0; // variable to check whether the current block was found --> also used for "jofis-block-type"
     otype = (((uint)buf[i]<<16)+((uint)buf[i+1]<<8)+(uint)buf[i+2]); i+=3; // im Vertex-Bereich besteht ein Blocktype nur aus 3 bytes!
     while ( (lod==0) && (otype==0) ) { printf("# 0-type -> retrying!\n"); otype = (((uint)buf[i]<<16)+((uint)buf[i+1]<<8)+(uint)buf[i+2]); i+=3; }
     printf("\n# .");
     printf("\n# Vertex-Blocktype %06x @ %08x  BLOX %d/%d\n", otype, (i-0), cublox, totalblocks); 


     // Case-Switching nach Vertex-Block-Type -------------------------------------------------------------------------------------------------

     // ============================================================================= VERTEX-AREA-SWITCHING
#if 0
     printf("# lod is %d\n", lod);
     if ( lod != 0 ) 
     { 
       /* kein test, stimmt einfach ;) */           // xx xx xx xx --> Vertex-Area
       printf("# this is a level of detail block at level %d\n", lod);
       lod--; 
       bl=1; ja=-2; 
     } 
     else 
     {
       if ( ( lod == 0 ) && ( otype < 10 ) ) // 00 00 02 xx xx xx xx --> Vertex-Area
       {
         printf("# setting this block to level of detail %d\n", otype); 
         lod = otype-1;
         bl=4; ja=-1;
       }
       else
       {
         /*
         if ( ( ( otype & 0x0000ff ) == 0x000001 ) && ( buf[i] == 0 ) && ( buf[i+1] == 0 ) )  // anzahl, 01 00 00 
         {
           printf("# FIX ME - does this occure anymore??\n");  // yes in: missions/mise07b-saliery/scene.4ds  type=f10001 @ 000b26da  BLOX 246/293
                                                               // yes in: missions/freeride/scene.4ds
                                                               // yes in: missions/00menu/scene.4ds           type=3d0001
           printf("# ANZAHL = %04x ( %d ) --> real type: %02x %02x %02x\n", (otype>>8), (otype>>8), (otype&255), buf[i], buf[i+1] );
           i+=2;
           bl=3; ja=3;  // 01 xx xx yy yy yy --> 10 FL, ST9(2FN)
         }
         */
         m = ( otype >> 16 ); k = ( otype & 255 );
         if ( ( m == 0x01 ) || ( m == 0x05 ) || ( m == 0x06 ) ) printf("# NORMAL CASE...\n");
         else
         {
          if ( ( k == 0x01 ) || ( k == 0x05 ) || ( k == 0x06 ) ) 
          { 
            printf("# ANZAHL CASE: %04x --> skipping to ", (otype>>8));
            i-=1;
            otype = (((uint)buf[i]<<16)+((uint)buf[i+1]<<8)+(uint)buf[i+2]); 
            printf(" OTYPE= %06x\n", otype);
            i+=3; 
          }
          else printf("# UNKNOWN CASE...\n");
         }
       }
     }
#endif

     if ( ja == 0 )
     {

     // ============================================================================= 10-9-SWITCHING

     if ( ( otype & 0xff0000 ) == 0x010000 ) { bl=3; ja=3; } // 01 xx xx yy yy yy --> 10 FL, ST9(2FN)

     // ============================================================================= 10-9-6-SWITCHING

     if ( ( otype & 0xff0000 ) == 0x060000 ) { bl=0; ja=2; } // 06 xx xx --> 10 FL, ST9(2FN), 6FL

     // ============================================================================= 10-STX-SOMETHING
     
     if ( ( otype & 0xff0000 ) == 0x050000 ) { bl=0; ja=4; } // 05 xx xx --> 10 FL, ST7d(2FN), 4FL, ++ [freeride/scene.4ds]

     // ============================================================================= UNKNOWN STUFF under debugging

     if ( otype == 0x020000 ) { bl=2; ja=1; } // 02 00 00 * * --> nothing! [ THIS IS AN UGLY HACK! ]
     // if ( otype == 0x020000 ) { bl=8; ja=3; } // 02 00 00 * --> 10 FL, ST9(2FN) // missions/mise07b-saliery/scene.4ds 
     // if ( otype == 0x020000 ) { bl=5; ja=2; } // 02 00 00 * --> 10 FL, ST9(2FN) // missions/mise07b-saliery/scene.4ds 
     // FMVblackha00.4ds:  # 02 00 00 --> 10 FL, ST9(2FN), 6 FL  [ tail: 00 01 06 00 00 ]                 bl=5; ja=2;
     // mise07b-saliery:   # 02 00 00 --> 10 FL, ST9(2FN)        [ tail: 00 00 01 04 00 2a 35 00 ]        bl=8; ja=3;

     if ( otype == 0x003200 ) { bl=12; ja=1; } //  nothing!

     /* ist jetzt oben im ANZAHL-FALL drin ??? bitte ueberpruefen!
     if ( otype == 0x030006 ) { bl=5; ja=2; } // 03 00 06 xx xx xx xx xx --> 10 FL, ST9(2FN), 6 FL
     */

     // if ( ( otype & 0xff0000 ) == 0x1e0000 ) { bl=5; ja=3; } // 1e xx xx yy yy yy yy yy --> 10 FL, ST9(2FN) missions/mise08-hotel/scene.4ds (FALSCH!)
     // ebenso hotel: Vertex-Blocktype 010000 @ 00062f4a  BLOX 156/1171,  NORMAL CASE..., 01 00 00 --> 10 FL, ST9(2FN)  [ tail: 00 00 54 ]     (FALSCH!)

     // ============================================================================= Presumed to be animation-types
     if ( otype == 0x120000 ) { printf("# **ANIMATION-TYPE??  \n"); bl=0; ja=-1997; } // Gangster01.4ds
     if ( otype == 0x120300 ) { printf("# **ANIMATION-TYPE??  \n"); bl=2; ja=-1997; } // Alice1.4ds, CarlZen1.4ds
     if ( otype == 0x121400 ) { printf("# **ANIMATION-TYPE??  \n"); bl=2; ja=-1997; } // Carlo.4ds

     }

     // Case-Switching nach My-Block-Type -----------------------------------------------------------------------------------------------------
     
     // =============================================== DEBUG
     if ( ja == -1997)  // DEBUG
     {
       printf("# ");
       k = ( otype >> 16 ) & 255; printf("%02x ", k );
       k = ( otype >>  8 ) & 255; printf("%02x ", k );
       k =   otype         & 255; printf("%02x ", k );
       printf("--> DEBUG ");
       if ( bl == 0 ) printf("[ notail ]\n");
       else { printf("[ tail: "); for (k=0; k<bl; k++) printf("%02x ", buf[i+k]); i+=bl; printf("]\n"); }

       printf("\n\n# ***** ENTERING DEBUG MODE *****\n\n");
       /*
       while (i<flen)
       {
         printf("# POS[%08x] = %02x %02x %02x %02x --> %08x --> %f\n", i, buf[i], buf[i+1], buf[i+2], buf[i+3], 
                                                                     *(unsigned int*)((int)buf+i), *(float*)((int)buf+i));
         i+=4;
       }
       */
       raus=1;
     }

     // =============================================== ja < 0 : Vertex-Area
/*
     if ( ( ja == -1 ) || ( ja == -2 ) )  // VERTEX-AREA
     {
       printf("# ");
       k = ( otype >> 16 ) & 255; printf("%02x ", k );
       k = ( otype >>  8 ) & 255; printf("%02x ", k );
       k =   otype         & 255; printf("%02x ", k );
       printf("--> Vertex-Area ");
       if ( bl == 0 ) printf("[ notail ]\n");
       else {   if ( bl == 4 ) { printf("[ tail: %02x %02x %02x %02x = %f ]\n", buf[i], buf[i+1], buf[i+2], buf[i+3], *(float*)&buf[i] ); i+=bl; }
                else { printf("[ tail: "); for (k=0; k<bl; k++) printf("%02x ", buf[i+k]); i+=bl; printf("]\n");  } }

       if ( ja == -2 ) KILL=do_a_kill; 
       i=VERTEX_AREA(i);
     }
*/
     // =============================================== ja > 0 : Header-Types 

     if ( ja > 0 ) cublox++; // actually, incremeting here is done too early, but down below I need cublox+1, so it's easier to increment here already!

     if ( ja == 1 )  // NOTHING
     {
       printf("# ");
       k = ( otype >> 16 ) & 255; printf("%02x ", k );
       k = ( otype >>  8 ) & 255; printf("%02x ", k );
       k =   otype         & 255; printf("%02x ", k );
       printf("--> NOTHING  ");

       if ( bl == 0 ) printf("[ notail ]\n");
       else { printf("[ tail: "); for (k=0; k<bl; k++) printf("%02x ", buf[i+k]); i+=bl; printf("]\n"); }
     }

     if ( ja == 2 )  // 10FL, ST9(2FN), 6FL
     {
       printf("# ");
       k = ( otype >> 16 ) & 255; printf("%02x ", k );
       k = ( otype >>  8 ) & 255; printf("%02x ", k ); 
       k =   otype         & 255; printf("%02x ", k );
       printf("--> 10 FL, ST9(2FN), 6 FL  ");

       trafref[cublox]=( otype >>  8 ) & 255;
       traftype[cublox]=2;

       if ( bl == 0 ) printf("[ notail ]\n");
       else { printf("[ tail: "); for (k=0; k<bl; k++) printf("%02x ", buf[i+k]); i+=bl; printf("]\n"); }

       printf("# [2.Grp] BLOX = %02x -- transBLOX = %02x [ref-type=%d]\n", cublox, trafref[cublox], traftype[trafref[cublox]]);
       // cublox werden weiter oben schon hochgezaehlt, so sind sie hier eins zu hoch!

       #ifdef HACK 
       printf("# Group Transform %d\n", k);
       printf("# TRANSLATE X,Y,Z\n"); Hprint(i, 3);
       printf("# SCALE X,Y,Z\n"); Hprint(i+3*4, 3);
       printf("# ROTATE W,X,Y,Z\n"); Hprint(i+6*4, 4);
       #endif


       mtx = *(float*)&buf[i]; i+=4; // Vertex Translation X
       mty = *(float*)&buf[i]; i+=4; // Vertex Translation Y
       mtz = *(float*)&buf[i]; i+=4; // Vertex Translation Z

       msx = *(float*)&buf[i]; i+=4; // Vertex Scale X
       msy = *(float*)&buf[i]; i+=4; // Vertex Scale Y
       msz = *(float*)&buf[i]; i+=4; // Vertex Scale Z

       mrx = *(float*)&buf[i]; i+=4; // Vertex Rotate X
       mry = *(float*)&buf[i]; i+=4; // Vertex Rotate Y
       mrz = *(float*)&buf[i]; i+=4; // Vertex Rotate Z
       mrw = *(float*)&buf[i]; i+=4; // Vertex Rotate W

       printf("# PRE Group translation:  %f, %f, %f\n", mtx, mty, mtz);
       printf("# PRE Group scale:        %f, %f, %f\n", msx, msy, msz);
       printf("# PRE Group quaternion:   %f, %f, %f, %f\n", mrx, mry, mrz, mrw);
       m=trafref[cublox]; if ( cublox != m )  // if both are equal, there's nothing to do!
       {
        omtx=trafo[m][0]; omty=trafo[m][1]; omtz=trafo[m][2];
        omsx=trafo[m][3]; omsy=trafo[m][4]; omsz=trafo[m][5];
        omrx=trafo[m][6]; omry=trafo[m][7]; omrz=trafo[m][8]; omrw=trafo[m][9];

        printf("# ...\n");
        printf("# RED Group translation:  %f, %f, %f\n", omtx, omty, omtz);
        printf("# RED Group scale:        %f, %f, %f\n", omsx, omsy, omsz);
        printf("# RED Group quaternion:   %f, %f, %f, %f\n", omrx, omry, omrz, omrw);

        mtx += omtx; mty += omty; mtz += omtz;
        msx *= omsx; msy *= omsy; msz *= omsz;

        // Quaternionen Multiplikation: Q1=(w1, x1, y1, z1), Q2=(w2, x2, y2, z2), Q1 * Q2 
        w1 =omrx; x1 =omry ; y1 =omrz; z1 =omrw;
        w2 = mrx; x2 = mry ; y2 = mrz; z2 = mrw;
        //
        ow = w1*w2 - x1*x2 - y1*y2 - z1*z2;
        ox = w1*x2 + x1*w2 + y1*z2 - z1*y2;
        oy = w1*y2 + y1*w2 + z1*x2 - x1*z2;
        oz = w1*z2 + z1*w2 + x1*y2 - y1*x2;
        //
        mrx = ow ; mry = ox; mrz = oy; mrw = oz;
       }

       printf("# ...\n");
       printf("# [T] Group translation:  %f, %f, %f\n", mtx, mty, mtz);
       printf("# [T] Group scale:        %f, %f, %f\n", msx, msy, msz);
       printf("# [T] Group quaternion:   %f, %f, %f, %f\n", mrx, mry, mrz, mrw);

       trafo[cublox][0]=mtx; trafo[cublox][1]=mty; trafo[cublox][2]=mtz;
       trafo[cublox][3]=msx; trafo[cublox][4]=msy; trafo[cublox][5]=msz;
       trafo[cublox][6]=mrx; trafo[cublox][7]=mry; trafo[cublox][8]=mrz; trafo[cublox][9]=mrw;

       k=0;
       subtype=buf[i]; i++;
       printf("# subtype: %02x\n", subtype);
       if ( subtype == 0x09 ) { k=1; i+=print2names(i); } // 2 names: liefert die anzahl gedruckter buchstaben+2 zurueck (2 bytes=>laengenkennung von namen)
       if ( k == 0 ) { raus=1; printf("# **error2** subtype not found!\n"); }
       printfloats(6,i); i+=6*4;
     }

     if ( ja == 3 )  // 10FL, ST9(2FN)
     {
       printf("# ");
       k = ( otype >> 16 ) & 255; printf("%02x ", k ); // type = k;
       k = ( otype >>  8 ) & 255; printf("%02x ", k ); subtype = k;
       k =   otype         & 255; printf("%02x ", k );
       printf("--> 10 FL, ST9(2FN)  ");

       if ( bl < 2 ) trafref[cublox]=-1; else trafref[cublox]=buf[i+1];  // trafref ==> parent, 0 = no parent --> here: 0 = identity matrix
       traftype[cublox]=3;

       if ( bl == 0 ) printf("[ notail ]\n");
       else { printf("[ tail: "); for (k=0; k<bl; k++) printf("%02x ", buf[i+k]); i+=bl; printf("]\n"); }

       printf("# [3.Obj] BLOX = %02x -- transBLOX = %02x [ref-type=%d]\n", cublox, trafref[cublox], traftype[trafref[cublox]]);
       // cublox werden weiter oben schon hochgezaehlt, so sind sie hier eins zu hoch!

       #ifdef HACK 
       printf("# Object Transform %d\n", k);
       printf("# TRANSLATE X,Y,Z\n"); Hprint(i, 3);
       printf("# SCALE X,Y,Z\n"); Hprint(i+3*4, 3);
       printf("# ROTATE W,X,Y,Z\n"); Hprint(i+6*4, 4);
       #endif

       tx = *(float*)&buf[i]; i+=4; // Vertex Translation X
       ty = *(float*)&buf[i]; i+=4; // Vertex Translation Y
       tz = *(float*)&buf[i]; i+=4; // Vertex Translation Z

       sx = *(float*)&buf[i]; i+=4; // Vertex Scale X
       sy = *(float*)&buf[i]; i+=4; // Vertex Scale Y
       sz = *(float*)&buf[i]; i+=4; // Vertex Scale Z

       rx = *(float*)&buf[i]; i+=4; // Vertex Rotate X
       ry = *(float*)&buf[i]; i+=4; // Vertex Rotate Y
       rz = *(float*)&buf[i]; i+=4; // Vertex Rotate Z
       rw = *(float*)&buf[i]; i+=4; // Vertex Rotate W

       #ifdef TELL_ME_ALL
       printf("# PRE Object translation:  %f, %f, %f\n", tx, ty, tz);
       printf("# PRE Object scale:        %f, %f, %f\n", sx, sy, sz);
       printf("# PRE Object quaternion:   %f, %f, %f, %f\n", rx, ry, rz, rw);
       #endif
       m=trafref[cublox]; if ( cublox != m )  // if both are equal, there's nothing to do!
       {
        omtx=trafo[m][0]; omty=trafo[m][1]; omtz=trafo[m][2];
        omsx=trafo[m][3]; omsy=trafo[m][4]; omsz=trafo[m][5];
        omrx=trafo[m][6]; omry=trafo[m][7]; omrz=trafo[m][8]; omrw=trafo[m][9];

        #ifdef TELL_ME_ALL
        printf("# ...\n");
        printf("# RED Object translation:  %f, %f, %f\n", omtx, omty, omtz);
        printf("# RED Object scale:        %f, %f, %f\n", omsx, omsy, omsz);
        printf("# RED Object quaternion:   %f, %f, %f, %f\n", omrx, omry, omrz, omrw);
        #endif

        // if ( cublox == 8 ) { printf("# jofis\n"); omsx=1.0; omsy=1.0/0.595238; omsz=1.0; }

        tx += omtx; ty += omty; tz += omtz;
        sx *= omsx; sy *= omsy; sz *= omsz;

        // Quaternionen Multiplikation: Q1=(w1, x1, y1, z1), Q2=(w2, x2, y2, z2), Q1 * Q2 
        w1 =omrx; x1 =omry ; y1 =omrz; z1 =omrw;
        w2 =  rx; x2 =  ry ; y2 =  rz; z2 =  rw;
        //
        ow = w1*w2 - x1*x2 - y1*y2 - z1*z2;
        ox = w1*x2 + x1*w2 + y1*z2 - z1*y2;
        oy = w1*y2 + y1*w2 + z1*x2 - x1*z2;
        oz = w1*z2 + z1*w2 + x1*y2 - y1*x2;
        //
        rx = ow ; ry = ox; rz = oy; rw = oz;
       }

       #ifdef TELL_ME_ALL
       printf("# ...\n");
       printf("# [T] Object translation:  %f, %f, %f\n", tx, ty, tz);
       printf("# [T] Object scale:        %f, %f, %f\n", sx, sy, sz);
       printf("# [T] Object quaternion:   %f, %f, %f, %f\n", rx, ry, rz, rw);
       #endif

       trafo[cublox][0]=tx; trafo[cublox][1]=ty; trafo[cublox][2]=tz;
       trafo[cublox][3]=sx; trafo[cublox][4]=sy; trafo[cublox][5]=sz;
       trafo[cublox][6]=rx; trafo[cublox][7]=ry; trafo[cublox][8]=rz; trafo[cublox][9]=rw;

       printf("# unknown char: %02x\n", buf[i]); i++;
       i+=print2names(i); // 2 names: liefert die anzahl gedruckter buchstaben+2 zurueck (2 bytes=>laengenkennung von namen)

       m=0;
       if ( ( subtype == 0 ) || ( subtype == 3 ) )
       // subtype 0: many things, e.g. 00menu/scene.4ds, models/fordtTud00.4ds
       // subtype 3: models/tommy.4ds
       {
         k = *(short int*)&buf[i]; i+=2; printf("# MeshReference %d\n", k);
         if ( k == 0 ) { m=1; i=VERTEX_AREA(i); }
                  else printf("# what to do??\n");
       }
       if ( m == 0 ) printf("# ERROR. HERE'S SOMETHING I DONT UNDERSTAND\n");
     }

     if ( ja == 4 )  // 10FL, ST7d(2FN), 4 FL
     {
       printf("# ");
       k = ( otype >> 16 ) & 255; printf("%02x ", k );
       k = ( otype >>  8 ) & 255; printf("%02x ", k );
       k =   otype         & 255; printf("%02x ", k );
       printf("--> 10 FL, ST7d(2FN), 4 FL  ");

       trafref[cublox]=( otype >>  8 ) & 255;
       traftype[cublox]=4;

       if ( bl == 0 ) printf("[ notail ]\n");
       else { printf("[ tail: "); for (k=0; k<bl; k++) printf("%02x ", buf[i+k]); i+=bl; printf("]\n"); }

       #ifdef HACK 
       printf("# Unknown Transform %d\n", k);
       printf("# TRANSLATE X,Y,Z\n"); Hprint(i, 3);
       printf("# SCALE X,Y,Z\n"); Hprint(i+3*4, 3);
       printf("# ROTATE W,X,Y,Z\n"); Hprint(i+6*4, 4);
       #endif

       tx = *(float*)&buf[i]; i+=4; // Vertex Translation X
       ty = *(float*)&buf[i]; i+=4; // Vertex Translation Y
       tz = *(float*)&buf[i]; i+=4; // Vertex Translation Z

       sx = *(float*)&buf[i]; i+=4; // Vertex Scale X
       sy = *(float*)&buf[i]; i+=4; // Vertex Scale Y
       sz = *(float*)&buf[i]; i+=4; // Vertex Scale Z

       rx = *(float*)&buf[i]; i+=4; // Vertex Rotate X
       ry = *(float*)&buf[i]; i+=4; // Vertex Rotate Y
       rz = *(float*)&buf[i]; i+=4; // Vertex Rotate Z
       rw = *(float*)&buf[i]; i+=4; // Vertex Rotate W

       printf("# [T] ...\n");
       printf("# [T] ??? translation:  %f, %f, %f\n", tx, ty, tz);
       printf("# [T] ??? scale:        %f, %f, %f\n", sx, sy, sz);
       printf("# [T] ??? quaternion:   %f, %f, %f, %f\n", rx, ry, rz, rw);

       trafo[cublox][0]=tx; trafo[cublox][1]=ty; trafo[cublox][2]=tz;
       trafo[cublox][3]=sx; trafo[cublox][4]=sy; trafo[cublox][5]=sz;
       trafo[cublox][6]=rx; trafo[cublox][7]=ry; trafo[cublox][8]=rz; trafo[cublox][9]=rw;


       printf("# unknown char: %02x\n", buf[i]); i++;
       i+=print2names(i); // 2 names: liefert die anzahl gedruckter buchstaben+2 zurueck (2 bytes=>laengenkennung von namen)

       i=printfloats(2,i); 
       // naechster wert ist (int=4 bytes!) anzahl vertices
       // naechster wert ist (int=4 bytes!) anzahl triangles
       k=*(int*)&buf[i]; printf("# anz. vert= %d = %08x\n", k, k ); i+=4; j= k*3*4;
       k=*(int*)&buf[i]; printf("# anz. tris= %d = %08x\n", k, k ); i+=4; j+=k*3*2;
       printf("# skipping vertices and tris @ %08x len=%08x\n", i, j ); i+=j; // skipping vert+tris
       printf("# this skipping is _not_ necessary!!!!\n# it's simply because I'm too lazy to fix it...\n");
       printf("# bounding box?:\n"); i=printfloats(6,i);
       
       k=buf[i]; printf("# Anzahl Seltsame Bloecke: %d [%02x] @ %08x\n", k, k, i ); i++; // Anzahl der seltsamen Bloecke
       for (j=0; j<k; j++)
       {
        l=buf[i]; m=i; i++;
        printf("# something (int): %d ( %08x ) @ %08x\n", *(int*)&buf[i], *(int*)&buf[i], i ); i+=4;
        printf("# bounding box?:\n"); i=printfloats(6,i);
        printf("# Triple-Floats = %d [%02x] @ %08x\n", l,l, m);
        for (m=0; m<l; m++) 
        {
          printf("# [%02x]  ", m);
          printf("%f ", *(float*)&buf[i]); i+=4;
          printf("%f ", *(float*)&buf[i]); i+=4;
          printf("%f ", *(float*)&buf[i]); i+=4;
          printf("\n");
        }
       }

       // printf("# %02x\n", buf[i]); i++;
       // i=printfloats(28,i);
       //
       /*
       // debug and end
       printf("# -- rest is unknown --\n");
       j=i+50*4;
       j=0x01feb63+1;
       while ((i<flen)&&(i<j))
       {
         printf("# POS[%08x] = %02x %02x %02x %02x --> %08x --> %f\n", i, buf[i], buf[i+1], buf[i+2], buf[i+3], 
                                                                     *(unsigned int*)((int)buf+i), *(float*)((int)buf+i));
         i+=4;
       }
       // exit(0);
       */
     }

     // =============================================== ja = 0 : Error
     if (ja==0) // ERROR
     {
      printf("\n\n# **ERROR** Blocktype not found!\n");
      printf("\n# Unknown-Block:\n");
      for (k=0; k<20; k++) { printf("# [%08x] ", i); printrhex(i, i+16); i+=16; }
      raus=1;
     }

   }

   // ENDE
   if ((raus==0)&&(i<flen)) // schluss noch ausgeben
   {
     printf("\n\n# this is the rest:\n# [%08x]  ",i); printrhex(i,flen); 
   }

   // 
   //
   // --------- generating shell-scripts which copy only the neccessary textes out of the game folder into the current directory --------------------------
   //
   //

   #ifdef MGFX
   i=0; savbuf[i++]='m'; savbuf[i++]='a'; savbuf[i++]='f'; savbuf[i++]='c'; savbuf[i++]='p'; savbuf[i++]='.';
   savbuf[i++]='s'; savbuf[i++]='h'; savbuf[i++]=0;
   handle=open(savbuf,O_CREAT|O_WRONLY|O_TRUNC,0644);
   if (fstat(handle,&staat)<0) {printf("ERROR occured creating file %s!\n", savbuf); exit(1);}
   m=sprintf(savbuf, "#!/bin/sh\n# shell-script to copy and convert the textures...\n# scene-file: %s\n", argv[1]); write(handle, savbuf, m);
   for (i=0; i<maxobj; i++) 
   { 
     if ( mats[i][0]!=0 ) 
     { 
       // manche bmps sind 8bit indexed, wir brauchen aber unbedingt 24-bit ppms, also konvertieren wir erst nach tga (das ist 24 bit) und dann nach ppm
       m=sprintf(savbuf, "convert \"/windos/games/Mafia/maps/%s\" \"%s.tga\"\n", mats[i], mats[i]); write(handle, savbuf, m);
       m=sprintf(savbuf, "tgatoppm \"%s.tga\" > \"%s.ppm\"\n", mats[i], splmats[i]); write(handle, savbuf, m);
       m=sprintf(savbuf, "rm \"%s.tga\"\n", mats[i]);write(handle, savbuf, m);
     }
   }
   close(handle);

   i=0; savbuf[i++]='m'; savbuf[i++]='a'; savbuf[i++]='f'; savbuf[i++]='l'; savbuf[i++]='s'; savbuf[i++]='.';
   savbuf[i++]='s'; savbuf[i++]='e'; savbuf[i++]='a'; savbuf[i++]=0;
   handle=open(savbuf,O_CREAT|O_WRONLY|O_TRUNC,0644);
   if (fstat(handle,&staat)<0) {printf("ERROR occured creating file %s!\n", savbuf); exit(1);}

   m=sprintf(savbuf, "# Sea-file for scene: %s\n", argv[1]); write(handle, savbuf, m);
   for (i=0; i<maxobj; i++) 
   { 
     if ( mats[i][0]!=0 ) 
     { 
       m=sprintf(savbuf, "\n# mat[%2d] %s\n", i, mats[i]); write(handle, savbuf, m);
       m=sprintf(savbuf, "%d 0 %s.ppm\n", i+1, splmats[i]); write(handle, savbuf, m);  // +1 sagt, dass ich mich irgendwo mal verzaehlt habe... *FIXME*
     }
   }
   close(handle);

   #endif


   #ifdef MGFRT
   i=0; savbuf[i++]='m'; savbuf[i++]='a'; savbuf[i++]='f'; savbuf[i++]='c'; savbuf[i++]='p'; savbuf[i++]='.';
   savbuf[i++]='s'; savbuf[i++]='h'; savbuf[i++]=0;
   handle=open(savbuf,O_CREAT|O_WRONLY|O_TRUNC,0644);
   if (fstat(handle,&staat)<0) {printf("ERROR occured creating file %s!\n", savbuf); exit(1);}
   m=sprintf(savbuf, "#!/bin/sh\n# shell-script to copy and convert the textures...\n# scene-file: %s\n", argv[1]); write(handle, savbuf, m);
   for (i=0; i<maxobj; i++) 
   { 
     if ( mats[i][0]!=0 ) 
     { 
       // manche bmps sind 8bit indexed, wir brauchen aber unbedingt 24-bit ppms, also konvertieren wir erst nach tga (das ist 24 bit) und dann nach ppm
       m=sprintf(savbuf, "convert \"/windos/games/Mafia/maps/%s\" \"%s.tga\"\n", mats[i], mats[i]); write(handle, savbuf, m);
       m=sprintf(savbuf, "tgatoppm \"%s.tga\" > \"%s.ppm\"\n", mats[i], splmats[i]); write(handle, savbuf, m);
       m=sprintf(savbuf, "rm \"%s.tga\"\n", mats[i]);write(handle, savbuf, m);
     }
   }
   close(handle);
   #endif


   #ifdef OBJ
   i=0; savbuf[i++]='m'; savbuf[i++]='a'; savbuf[i++]='f'; savbuf[i++]='c'; savbuf[i++]='p'; savbuf[i++]='.';
   #ifdef DOS_MODE
   savbuf[i++]='b'; savbuf[i++]='a'; savbuf[i++]='t'; savbuf[i++]=0;
   handle=open(savbuf,O_CREAT|O_WRONLY|O_TRUNC|O_BINARY,0644);
   if (fstat(handle,&staat)<0) {printf("ERROR occured creating file %s!\n", savbuf); exit(1);}
   m=sprintf(savbuf, "REM batch-script to copy the textures...\r\n"); write(handle, savbuf, m);
   m=sprintf(savbuf, "REM scene-file: %s\r\n",argv[1]); write(handle, savbuf, m);
   for (i=0; i<maxobj; i++) 
   { 
     if ( mats[i][0]!=0 ) { m=sprintf(savbuf, "copy E:\\Games\\Mafia\\maps\\%s %s\n", mats[i], splmats[i]); write(handle, savbuf, m); }
   }
   #else
   savbuf[i++]='s'; savbuf[i++]='h'; savbuf[i++]=0;
   handle=open(savbuf,O_CREAT|O_WRONLY|O_TRUNC,0644);
   if (fstat(handle,&staat)<0) {printf("ERROR occured creating file %s!\n", savbuf); exit(1);}
   m=sprintf(savbuf, "#!/bin/sh\n# shell-script to copy the textures...\n# scene-file: %s\n", argv[1]); write(handle, savbuf, m);
   for (i=0; i<maxobj; i++) 
   { 
     if ( mats[i][0]!=0 ) { m=sprintf(savbuf, "cp /windos/games/Mafia/maps/%s %s\n", mats[i], splmats[i]); write(handle, savbuf, m); }
   }
   #endif
   close(handle);

   // create the mtl-file
   i=0; 
   savbuf[i++]='m'; savbuf[i++]='a'; savbuf[i++]='f'; savbuf[i++]='l'; savbuf[i++]='s'; 
   savbuf[i++]='.'; savbuf[i++]='m'; savbuf[i++]='t'; savbuf[i++]='l'; savbuf[i++]=0;
   #ifdef DOS_MODE
   handle=open(savbuf,O_CREAT|O_WRONLY|O_TRUNC|O_BINARY,0644);
   #else
   handle=open(savbuf,O_CREAT|O_WRONLY|O_TRUNC,0644);
   #endif
   if (fstat(handle,&staat)<0) {printf("ERROR occured creating file %s!\n", savbuf); exit(1);}
  
   for (i=0; i<maxobj; i++) 
   {
     m=sprintf(savbuf, "newmtl mafmat%02d\n", i ); write(handle,savbuf,m);
     m=sprintf(savbuf, "Ka %f %f %f\n", cmats[i][0], cmats[i][1], cmats[i][2]); write(handle,savbuf,m);
     m=sprintf(savbuf, "Kd %f %f %f\n", cmats[i][3], cmats[i][4], cmats[i][5]); write(handle,savbuf,m);
     if ( splmats[i][0] != 0 ) {m=sprintf(savbuf, "map_Kd %s\n", splmats[i]); write(handle,savbuf,m);}
     m=sprintf(savbuf, "\n"); write(handle,savbuf,m);
     /*
     // printf("# newmtl %d-%s\n", i, splmats[i]);
     printf("# newmtl mafmat%02d\n", i );
     printf("# Ka %f %f %f\n", cmats[i][0], cmats[i][1], cmats[i][2]);
     printf("# Kd %f %f %f\n", cmats[i][3], cmats[i][4], cmats[i][5]);
     // n.a. printf("# Ke %f %f %f\n", cmats[i][6], cmats[i][7], cmats[i][8]);  // no way to specify the emissive color!
     // does not work! if ( splmats[i][0] != 0 ) printf("# map_Kd e:\\windows\\games\\mafia\\maps\\%s\n", splmats[i]);
     if ( splmats[i][0] != 0 ) printf("# map_Kd %s\n", splmats[i]);
     printf("# \n");
     */
   }

   close(handle);
   #endif


   #ifdef VRML2
   i=0; savbuf[i++]='m'; savbuf[i++]='a'; savbuf[i++]='f'; savbuf[i++]='c'; savbuf[i++]='p'; savbuf[i++]='.';
   #ifdef DOS_MODE
   savbuf[i++]='b'; savbuf[i++]='a'; savbuf[i++]='t'; savbuf[i++]=0;
   handle=open(savbuf,O_CREAT|O_WRONLY|O_TRUNC|O_BINARY,0644);
   if (fstat(handle,&staat)<0) {printf("ERROR occured creating file %s!\n", savbuf); exit(1);}
   m=sprintf(savbuf, "REM batch-script to copy the textures...\r\n"); write(handle, savbuf, m);
   m=sprintf(savbuf, "REM scene-file: %s\r\n",argv[1]); write(handle, savbuf, m);
   for (i=0; i<maxobj; i++) 
   { 
     if ( mats[i][0]!=0 ) { m=sprintf(savbuf, "copy E:\\Games\\Mafia\\maps\\%s %s\n", mats[i], splmats[i]); write(handle, savbuf, m); }
   }
   #else
   savbuf[i++]='s'; savbuf[i++]='h'; savbuf[i++]=0;
   handle=open(savbuf,O_CREAT|O_WRONLY|O_TRUNC,0644);
   if (fstat(handle,&staat)<0) {printf("ERROR occured creating file %s!\n", savbuf); exit(1);}
   m=sprintf(savbuf, "#!/bin/sh\n# shell-script to copy the textures...\n# scene-file: %s\n", argv[1]); write(handle, savbuf, m);
   for (i=0; i<maxobj; i++) 
   { 
     if ( mats[i][0]!=0 ) { m=sprintf(savbuf, "cp /windos/games/Mafia/maps/%s %s\n", mats[i], splmats[i]); write(handle, savbuf, m); }
   }
   #endif
   close(handle);
   #endif

   free(buf); 
}
