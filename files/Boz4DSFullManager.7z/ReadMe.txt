4ds Manager


  Author: djbozkosz
    Size: 403.32KB
Added on: 13 Apr 2014


With this tool you can edit a lot of settings regarding your .4ds model including both objects and materials.
It allows you to animate textures and create special values for them and you can set the draw distance levels for objects.