Menu.def Editor
Verze: 1.00
Release date: 2012.10.02
Created by: djbozkosz
Web site: www.djbozkosz.wz.cz

1. INFORMATIONS
Tool for adding, modifying and deleting menu items in the Mafia game, which are stored in menu.def file.

2. INSTALATION
Before use, you have to extract tables folder with MafiaDataXtractor.
After load main file, please open textdb_xx.def file, which contains a text strings database. In the editor is used for show text labels in the menu items.

3. USING
Menu items are bouded with new window definition: wint, wind, winc, etc... and end of window: stop. Window order is strictly linked with Game.exe. So you cannot insert new windows somewhere in the file. Item ID is some action, which is controlled by Game.exe too.
You can insert a new item by duplicating old item. You can also copy all data from the one item with Shift+Ctrl+C and paste it with Shift+Ctrl+V.

4. SAVING
The file isn't automatically saved, so you should save it with Ctrl+S.
Before modifying, please backup the original file!

5. STRING DATABASE
You can modify the strings with Mafia Text Editor.