1. Add new pedestrian zone:

 1.1 Select "Pedestrian point"
 1.2 Enter 3 coordinates - X,Y,Z (at the bottom). - It is the first point of the
     pedestrian zone.
 1.3 Enter Others 3 coordinates.
 1.4 If you want to finish pedistrian zone, select "Finish" and enter point.
 1.5 That is all.

2. Add airplane way:

 2.1 Make the same as in "Pedistrian zone", but select "Techno-point" and enter
     in "N.P." of first point number of point for airplane.
 2.2 Import airplane in scene2.bin by means DCED program.
 2.3 Launh airplane by script "airplane_start Actor, N.P., Speed"

3. Add train:

 3.1 Make the same as in "Airplane way".
 3.2 Launh train by script "airplane_start Actor, N.P., 0"


===========================================================
Akay, 2006
mafpr@nm.ru